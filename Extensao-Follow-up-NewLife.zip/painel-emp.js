// Aba Empreendimentos do painel: busca nos dois sites, ficha, mensagem pronta e "Colocar na conversa".
// DWV → mensagem com o link do hotsite (com o nome e o contato do corretor). Top 3 → fotos + texto (sem link, sem agenciador).
let empMostrar = 60, detalheTop3 = {}, procuraAtual = null;

const CID_CANON = [
  [/balneario camboriu|bal\.? camboriu|^bc$/, "Balneário Camboriú"], [/^camboriu$/, "Camboriú"], [/itapema/, "Itapema"],
  [/porto belo/, "Porto Belo"], [/bombinhas/, "Bombinhas"], [/itajai/, "Itajaí"], [/navegantes/, "Navegantes"],
  [/tijucas/, "Tijucas"], [/celso ramos/, "Gov. Celso Ramos"], [/picarras/, "Balneário Piçarras"], [/penha/, "Penha"],
];
function cidadeCanon(c){ const n = norm(c || "").trim(); const a = CID_CANON.find(([re]) => re.test(n)); return a ? a[1] : (c || "").trim(); }

// "1200", "R$ 1.200", "1.200,50" → "R$ 1.200"
function reais(s){ const n = Number(String(s || "").replace(/[^\d,]/g, "").replace(",", ".")); return n ? "R$ " + Math.round(n).toLocaleString("pt-BR") : ""; }
function dinheiroTexto(v){
  if (!v) return "";
  if (v >= 1e6) { const m = v / 1e6; return "R$ " + m.toLocaleString("pt-BR", {maximumFractionDigits: m >= 10 ? 1 : 2}) + (m < 2 ? " milhão" : " milhões"); }
  return "R$ " + Math.round(v / 1e3) + " mil";
}

// ---------- lista
function aoMudarImoveis(){
  const n = todosImoveis().length;
  $("nE").textContent = n || "";
  preencherCidades();
  if (aba === "emp" && !atual) renderEmp();
  renderStatusEmp();
}
function preencherCidades(){
  const sel = $("eCidade"), atualV = sel.value;
  const cont = {};
  todosImoveis().forEach((it) => { const c = cidadeCanon(it.cidade); if (c) cont[c] = (cont[c] || 0) + 1; });
  const ops = Object.entries(cont).sort((a, b) => b[1] - a[1]);
  const html = `<option value="">Todas as cidades</option>` + ops.map(([c, k]) => `<option value="${esc(c)}">${esc(c)} (${k})</option>`).join("");
  if (sel.dataset.h !== html) { sel.innerHTML = html; sel.dataset.h = html; sel.value = atualV; }
}
function renderStatusEmp(){
  const el = $("empStatus"); if (!el) return;
  const linha = (f) => {
    const F = FONTES[f], n = IMOVEIS[f].length, q = IMOVEIS.quando[f];
    if (IMOVEIS.baixando[f]) return `<span class="carregando">${F.nome}: atualizando…</span>`;
    if (IMOVEIS.erro[f]) return `<span class="erro">${F.nome}: ${esc(IMOVEIS.erro[f])}</span>`;
    return `<span>${F.nome}: ${n} ${q ? "· " + haQuanto(q).replace("hoje", "atualizado hoje") : ""}</span>`;
  };
  el.innerHTML = linha("dwv") + linha("top3") + `<button type="button" class="x" data-atualizar-emp title="Baixar de novo dos sites">↻</button>`;
}
function filtroEmp(){
  return {q: norm($("busca").value.trim()), cid: $("eCidade").value, qt: Number($("eQuartos").value) || 0,
    ate: Number($("eAte").value) || 0, fonte: $("eFonte").value, ordem: $("eOrdem").value};
}
function filtrarEmp(f){
  const esconder = $("esconder").checked && contato.chave;
  const r = todosImoveis().filter((it) =>
    (!f.fonte || it.f === f.fonte) && (!f.cid || cidadeCanon(it.cidade) === f.cid) &&
    (!f.qt || (it.q[1] ?? it.q[0] ?? 0) >= f.qt) && (!f.ate || (it.p && it.p <= f.ate)) &&
    (!f.q || norm([it.nome, it.constr, it.bairro, it.cidade, it.rua, it.tipo, it.un].join(" ")).includes(f.q)) &&
    !(esconder && jaRecebeu("e", it.id)));
  const pr = (it) => it.p || Infinity;
  if (f.ordem === "precoD") r.sort((a, b) => (b.p || 0) - (a.p || 0));
  else if (f.ordem === "novo") r.sort((a, b) => String(b.up).localeCompare(String(a.up)));
  else r.sort((a, b) => pr(a) - pr(b));
  return r;
}
function itemEmp(it, mini, motivo){
  const foto = fotoDe(it, 160);
  const nome = it.nome + (it.un ? ` · un. ${it.un}` : "");
  const linha = [cidadeCanon(it.cidade) + (it.bairro ? " · " + it.bairro : ""), quartosTxt(it), faixa(it.a, " m²")].filter(Boolean).join(" · ");
  const preco = it.p ? (it.f === "dwv" ? "a partir de " : "") + dinheiroTexto(it.p) : "preço sob consulta";
  return `<button class="item emp${mini ? " mini" : ""}" type="button" data-abrir="${esc(it.id)}" data-tipo="e"${motivo ? ` data-motivo="${esc(motivo)}"` : ""}>
    ${foto ? `<img class="foto-n" src="${esc(foto)}" alt="" loading="lazy">` : `<span class="foto-n vazio-f"></span>`}
    <span><b>${esc(nome)}</b><small>${esc(linha)}</small><small class="preco">${esc(preco)} <i class="fonte-tag ${it.f}">${FONTES[it.f].nome}</i></small>${marcaEnviado("e", it.id)}</span></button>`;
}
function renderEmp(){
  const f = filtroEmp(), lista = filtrarEmp(f);
  renderProcura();
  const base = todosImoveis();
  let html;
  if (!base.length) html = `<p class="vazio">${IMOVEIS.baixando.dwv || IMOVEIS.baixando.top3 ? "Baixando os empreendimentos do DWV e do Top 3… (a primeira vez leva até 1 minuto)" : "Nenhum empreendimento guardado ainda. Clique em ↻."}</p>`;
  else if (!lista.length) html = `<p class="vazio">Nada com esses filtros.</p>`;
  else html = `<p class="conta">${lista.length} encontrado${lista.length > 1 ? "s" : ""}</p>` + lista.slice(0, empMostrar).map((it) => itemEmp(it)).join("") +
    (lista.length > empMostrar ? `<button class="btn sec mais" type="button" data-mais-emp>Mostrar mais ${Math.min(60, lista.length - empMostrar)}</button>` : "");
  $("lista").innerHTML = html;
}
function renderProcura(){
  const el = $("procura");
  procuraAtual = contato.conversa && contato.conversa.length ? oQueProcura(contato.conversa) : null;
  if (!procuraAtual) { el.innerHTML = ""; return; }
  const nome = primeiroNome(contato.nome) || contato.nome;
  el.innerHTML = `<div class="procura">Pelo que ${esc(nome)} escreveu: <b>${esc(descreverProcura(procuraAtual))}</b> <button type="button" class="link" data-aplicar-procura>Filtrar assim</button></div>`;
}
function aplicarProcura(p){
  if (!p) return;
  $("eCidade").value = p.cidades && p.cidades.length === 1 ? cidadeCanon(p.cidades[0]) : "";
  $("eQuartos").value = p.quartos ? String(Math.min(4, p.quartos)) : "";
  const ates = [500000, 800000, 1000000, 1500000, 2000000, 3000000, 5000000, 10000000];
  $("eAte").value = p.ate ? String(ates.find((a) => a >= p.ate) || "") : "";
  empMostrar = 60; renderEmp();
}
// sugestão de empreendimento dentro da análise da conversa
function blocoEmpSugestao(){
  const p = contato.conversa && contato.conversa.length ? oQueProcura(contato.conversa) : null;
  if (!p || !todosImoveis().length) return "";
  const f = {q: "", cid: p.cidades && p.cidades.length === 1 ? cidadeCanon(p.cidades[0]) : "", qt: p.quartos || 0, ate: p.ate || 0, fonte: "", ordem: "preco"};
  const achou = filtrarEmp(f).filter((it) => !jaRecebeu("e", it.id));
  if (!achou.length) return "";
  const motivo = `ele procura ${descreverProcura(p)}`;
  return `<div class="assunto"><div class="ass-topo"><b>Imóveis que batem com o que ele procura</b></div><p class="trecho">${esc(descreverProcura(p))}</p>` +
    achou.slice(0, 3).map((it) => itemEmp(it, true, motivo)).join("") +
    `<button type="button" class="link" data-ver-procura>Ver os ${achou.length} na aba Empreendimentos</button></div>`;
}

// ---------- ficha
const DESTAQUES = ["Frente mar", "Vista mar", "Pé na areia", "Mobiliado", "Decorado", "Sol da manhã", "Piscina", "Rooftop", "Churrasqueira", "Lavabo", "Hidromassagem", "Andar alto", "Cobertura", "Dependência"];
function destaquesDe(texto){
  const t = norm(texto || "");
  return DESTAQUES.filter((d) => t.includes(norm(d))).slice(0, 4);
}
async function abrirEmp(id){
  const it = todosImoveis().find((x) => x.id === id); if (!it) return;
  if (atual && atual.tipo === "v") $("player").pause();
  atual = {tipo: "e", it: {...it, slug: it.id, titulo: it.nome}};
  $("ePor").innerHTML = motivoAtual ? `<div class="por">Sugerido porque ${esc(motivoAtual)} <button type="button" class="link" data-voltar>Voltar à análise</button></div>` : "";
  $("navegar").hidden = true; $("sugestao").hidden = true; $("ficha").hidden = true; $("fichaN").hidden = true; $("fichaE").hidden = false;
  const foto = fotoDe(it, 900);
  const preco = it.p ? (it.f === "dwv" ? "A partir de " : "") + real(it.p) : "Preço sob consulta";
  $("eCartao").innerHTML = `${foto ? `<img src="${esc(foto)}" alt="">` : ""}<span class="c-txt"><b>${esc(it.nome)}${it.un ? ` <em>un. ${esc(it.un)}</em>` : ""}</b>
    <small><i class="fonte-tag ${it.f}">${FONTES[it.f].nome}</i><span>${esc([it.constr, ondeFica({...it, cidade: cidadeCanon(it.cidade)})].filter(Boolean).join(" · "))}</span></small>
    <span class="preco-g">${esc(preco)}</span></span>`;
  const dados = [quartosTxt(it), it.s ? it.s + (it.s > 1 ? " suítes" : " suíte") : "", faixa(it.vg) ? faixa(it.vg) + " vaga" + (faixa(it.vg) === "1" ? "" : "s") : "",
    faixa(it.a, " m²"), it.tipo && it.f === "top3" ? it.tipo : "", entregaTxt(it), it.prog != null && it.f === "dwv" && it.prog > 0 && it.prog < 100 ? `obra ${it.prog}%` : "", it.rua].filter(Boolean);
  $("eDados").innerHTML = dados.map((d) => `<span class="dado">${esc(d)}</span>`).join("");
  $("eFotos").innerHTML = ""; $("eInterno").innerHTML = ""; $("eDescBox").hidden = true;
  if (it.f === "dwv") {
    $("eTitMsg").textContent = "Mensagem + link do empreendimento";
    $("eDica").innerHTML = "Na hora de colocar, <b>[link]</b> vira o hotsite do DWV com o <b>seu nome e contato</b>. O cliente abre sem login e o DWV mostra quando ele visitou.";
    $("eInterno").innerHTML = `<div class="interno"><b>Só pra você</b><a href="https://material.dwvapp.com.br/print/redevelopmentpdf/${esc(it.id.replace(/-/g, ""))}/${encodeURIComponent(it.nome)}.pdf" target="_blank" rel="noopener">Tabela de unidades e preços (PDF do DWV)</a></div>`;
    renderMsgsEmp(null);
  } else {
    $("eTitMsg").textContent = "Fotos + mensagem";
    $("eDica").textContent = "O link do Top 3 pede login, então o cliente recebe as fotos com o texto. O nome do agenciador nunca vai.";
    renderMsgsEmp(detalheTop3[it.id] || null);
    if (!detalheTop3[it.id]) {
      $("eFotos").innerHTML = `<p class="dica">Buscando fotos, descrição e forma de pagamento no Top 3…</p>`;
      const [det, fotos] = await Promise.all([noSite("top3", top3Ficha, [it.link]), top3Fotos(it.wp).catch(() => [])]);
      if (det && !det.erro) det.fotos = fotos;
      if (!atual || atual.it.id !== it.id) return;
      if (det.erro) { $("eFotos").innerHTML = `<div class="aviso">${det.erro === "login" ? "Entre no Top 3 neste Chrome (top3agenciamentos.com.br) pra trazer as fotos e a forma de pagamento." : esc(det.erro)}</div>`; return; }
      detalheTop3[it.id] = det;
      renderMsgsEmp(det);
    }
    renderTop3Extra(detalheTop3[it.id]);
  }
  mostrarJa(); window.scrollTo(0, 0);
}
function renderTop3Extra(det){
  if (!det) return;
  const extra = [det.suites && det.suites !== "0" ? det.suites + " suítes" : "", det.fase, det.entrega && "entrega " + det.entrega, det.construtora,
    reais(det.condominio) && "cond. " + reais(det.condominio), reais(det.iptu) && "IPTU " + reais(det.iptu)].filter(Boolean);
  $("eDados").insertAdjacentHTML("beforeend", extra.map((d) => `<span class="dado">${esc(d)}</span>`).join(""));
  const notas = det.pagamento.filter((p) => !/^entrada|\bx\b|parcel|financ|a vista|à vista|saldo/i.test(p));
  $("eInterno").innerHTML = `<div class="interno"><b>Só pra você</b>${det.agenciador ? `<span>Agenciador: ${esc(det.agenciador)}</span>` : ""}${notas.map((n) => `<span>${esc(n)}</span>`).join("")}<a href="${esc(atual.it.link)}" target="_blank" rel="noopener">Abrir no Top 3</a></div>`;
  const fotos = det.fotos || [];
  $("eFotos").innerHTML = fotos.length ? `<h3>Fotos que vão junto <span class="n-fotos" id="nFotos"></span></h3><div class="galeria">` +
    fotos.map((f, i) => `<label class="ft"><input type="checkbox" data-foto="${esc(f.g)}"${i < 5 ? " checked" : ""}><img src="${esc(f.t)}" alt="" loading="lazy"></label>`).join("") +
    `</div><p class="dica">Marque até 10. As 5 primeiras já vêm marcadas.</p>` : `<p class="dica">Esse imóvel não tem fotos no Top 3.</p>`;
  contarFotos();
  if (det.descricao) { $("eDesc").textContent = det.descricao; $("eDescBox").hidden = false; }
}
function contarFotos(){ const n = document.querySelectorAll("[data-foto]:checked").length; const el = $("nFotos"); if (el) el.textContent = n ? `(${n})` : ""; }
function fotosMarcadas(){ return [...document.querySelectorAll("[data-foto]:checked")].map((i) => i.dataset.foto).slice(0, 10); }

// ---------- mensagens (o motivo é o que o CLIENTE disse; sem travessão, sem "caro")
function msgsEmp(it, det){
  const p = contato.conversa && contato.conversa.length ? oQueProcura(contato.conversa) : null;
  const cid = cidadeCanon(it.cidade);
  const onde = [it.bairro, cid].filter(Boolean).join(", ");
  const q = quartosTxt(it), area = faixa(it.a, " m²");
  const bate = bateCom(it, p);
  const gancho = bate ? `Você me falou que procura ${procuraFalada(p)}, então separei` : "Separei";
  if (it.f === "dwv") {
    const specs = [q, area].filter(Boolean).join(", ");
    const preco = it.p ? `a partir de ${dinheiroTexto(it.p)}` : "";
    const ent = entregaTxt(it);
    const linha = [specs, preco, ent && ent !== "pronto" ? ent : ent === "pronto" ? "pronto pra morar" : ""].filter(Boolean).join(", ");
    return [
      {rot: "Apresentar o empreendimento", t: `Oi {nome}! ${gancho} um empreendimento pra você: o ${it.nome}, em ${onde}${it.constr ? ", da " + it.constr : ""}.\n${linha ? linha.charAt(0).toUpperCase() + linha.slice(1) + "." : ""}\n\nMontei uma página com fotos, plantas e localização pra você ver com calma: [link]\n\nQuer que eu te mande os valores das unidades disponíveis?`},
      {rot: "Mais uma opção", t: `{nome}, achei mais uma opção que vale você ver: ${it.nome}, em ${onde}. ${linha ? linha.charAt(0).toUpperCase() + linha.slice(1) + "." : ""}\n\nTá tudo aqui: [link]\n\nO que achou?`},
      {rot: "Lead frio", t: `Oi {nome}, tudo bem? Tô com uma opção em ${cid} que ${bate ? "tem a ver com o que você procurava" : "vale você conhecer"}: ${it.nome}${specs ? ", " + specs : ""}.\n\nDá uma olhada sem compromisso: [link]`},
    ];
  }
  const tipo = (it.tipo || "imóvel").toLowerCase();
  const d = det || {};
  const suites = d.suites && d.suites !== "0" ? `${d.suites} suíte${d.suites === "1" ? "" : "s"}` : "";
  const vagas = faixa(it.vg) ? `${faixa(it.vg)} vaga${faixa(it.vg) === "1" ? "" : "s"}` : "";
  const l1 = [it.un ? "Unidade " + it.un : "", area, suites || q, vagas].filter(Boolean).join(", ");
  const dest = destaquesDe(d.descricao);
  const pag = (d.pagamento || []).find((x) => /entrada|\bx\b|parcel|financ|vista|saldo/i.test(x)) || "";
  const custo = [reais(d.condominio) && "condomínio " + reais(d.condominio), reais(d.iptu) && "IPTU " + reais(d.iptu)].filter(Boolean).join(", ");
  const linhas = [l1, dest.length && dest.join(", "), it.p && "Valor: " + real(it.p), pag && "Pagamento: " + pag, custo && custo.charAt(0).toUpperCase() + custo.slice(1)].filter(Boolean).map((l) => "• " + l).join("\n");
  return [
    {rot: "Apresentar o imóvel", t: `Oi {nome}! ${gancho} esse ${tipo} pra você: ${it.nome}, em ${onde}.\n\n${linhas}\n\nTe mandei as fotos aqui. Quer marcar uma visita pra ver de perto?`},
    {rot: "Mais uma opção", t: `{nome}, olha mais essa opção: ${it.nome}, em ${onde}. ${[l1, it.p && "por " + dinheiroTexto(it.p)].filter(Boolean).join(", ")}.\n\nO que achou das fotos?`},
    {rot: "Lead frio", t: `Oi {nome}, tudo bem? Entrou uma unidade em ${cid} que ${bate ? "tem a ver com o que você procurava" : "vale você conhecer"}: ${it.nome}${l1 ? ", " + l1 : ""}.\n\nTe mandei umas fotos. Se fizer sentido, te passo os detalhes.`},
  ];
}
function renderMsgsEmp(det){
  if (!atual || atual.tipo !== "e") return;
  const frio = paradaAgora() > 0;
  $("eMsgs").innerHTML = blocoMsgs(msgsEmp(atual.it, det), "", frio);
}

// ---------- colocar na conversa
async function linkGuardado(it){
  const chave = "dwvlink:" + (contato.chave || "-") + ":" + it.id;
  const g = await chrome.storage.local.get(chave);
  if (g[chave]) return {url: g[chave]};
  const r = await linkDWV(it, contato.nome || $("nome").value.trim());
  if (r.url) chrome.storage.local.set({[chave]: r.url});
  return r;
}
async function prepararTextoEmp(texto){
  const it = atual.it;
  texto = preencher(texto);
  if (it.f !== "dwv" || !texto.includes("[link]")) return {texto};
  const r = await linkGuardado(it);
  if (r.erro) return {erro: r.erro === "login" ? "Entre no DWV neste Chrome (app.dwvapp.com.br) pra criar o link do cliente." : r.erro};
  return {texto: texto.replaceAll("[link]", r.url)};
}
async function colocarEmp(botao, texto){
  const it = atual.it;
  botao.disabled = true; const antes = botao.textContent; botao.textContent = it.f === "dwv" ? "Criando o link…" : "Preparando as fotos…";
  try {
    const pt = await prepararTextoEmp(texto);
    if (pt.erro) return toast(pt.erro, 6000);
    copiar(pt.texto);
    let r;
    if (it.f === "dwv") r = await falarComZap({acao: "texto", texto: pt.texto});
    else {
      const sel = fotosMarcadas();
      if (!sel.length) r = await falarComZap({acao: "texto", texto: pt.texto});
      else {
        botao.textContent = `Preparando ${sel.length} foto${sel.length > 1 ? "s" : ""}…`;
        const arquivos = [];
        for (const [i, u] of sel.entries()) { try { arquivos.push({dataUrl: await fotoParaZap(u), nome: `${it.nome.replace(/[^\p{L}\d]+/gu, "-")}-${i + 1}.jpg`, tipo: "image/jpeg"}); } catch (_) {} }
        if (!arquivos.length) return toast("Não consegui baixar as fotos do Top 3. A mensagem está copiada.", 5000);
        botao.textContent = "Colocando…";
        r = await falarComZap({acao: "colocarArquivos", arquivos, texto: pt.texto});
      }
    }
    if (r.erro === "sem-aba") return toast("Abra o WhatsApp Web (web.whatsapp.com) e a conversa do cliente.", 4500);
    if (r.erro === "recarregar") return toast("Recarregue a aba do WhatsApp (F5) uma vez e tente de novo.", 4500);
    if (!r.ok) return toast(r.erro || "Não deu certo. A mensagem está copiada.", 5000);
    registrar("e", it.id, it.nome); mostrarJa();
    if (r.linkOk === false) return toast("Atenção: o link não ficou inteiro na caixa do WhatsApp. Apague e cole de novo (⌘V): está copiado.", 7000);
    toast(it.f === "dwv" ? (r.escreveu ? "Pronto: mensagem e link na conversa. Espere a prévia e aperte Enter." : "A mensagem está copiada: clique na conversa e cole (⌘V).")
      : (r.legenda ? "Pronto: fotos e texto na conversa. Confira e aperte Enter." : "Fotos na conversa. Clique na legenda e cole (⌘V): o texto está copiado."), 5500);
  } finally { botao.disabled = false; botao.textContent = antes; }
}
async function copiarEmp(texto){
  const pt = await prepararTextoEmp(texto);
  if (pt.erro) return toast(pt.erro, 6000);
  toast(await copiar(pt.texto) ? "Copiado" + (atual.it.f === "dwv" ? " com o link do hotsite" : "") : "Não consegui copiar");
}

// ---------- eventos próprios da aba
["eCidade", "eQuartos", "eAte", "eFonte", "eOrdem"].forEach((id) => document.getElementById(id).addEventListener("change", () => { empMostrar = 60; renderEmp(); }));
document.addEventListener("change", (ev) => { if (ev.target.matches("[data-foto]")) { if (fotosMarcadas().length >= 10) document.querySelectorAll("[data-foto]:not(:checked)").forEach((i) => i.disabled = true); else document.querySelectorAll("[data-foto]").forEach((i) => i.disabled = false); contarFotos(); } });
