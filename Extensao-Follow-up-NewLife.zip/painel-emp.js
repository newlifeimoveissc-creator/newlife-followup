// Aba Empreendimentos do painel: busca nos dois sites, ficha, mensagem pronta e "Colocar na conversa".
// DWV → mensagem com o link do hotsite (com o nome e o contato do corretor). Top 3 → fotos + texto (sem link, sem agenciador).
let empMostrar = 60, detalheEmp = {}, procuraAtual = null;

const CID_CANON = [
  [/balneario camboriu|bal\.? camboriu|^bc$/, "Balneário Camboriú"], [/^camboriu$/, "Camboriú"], [/itapema/, "Itapema"],
  [/porto belo/, "Porto Belo"], [/bombinhas/, "Bombinhas"], [/itajai/, "Itajaí"], [/navegantes/, "Navegantes"],
  [/tijucas/, "Tijucas"], [/celso ramos/, "Gov. Celso Ramos"], [/picarras/, "Balneário Piçarras"], [/penha/, "Penha"],
];
function cidadeCanon(c){ const n = norm(c || "").trim(); const a = CID_CANON.find(([re]) => re.test(n)); return a ? a[1] : (c || "").trim(); }

// "1200", "R$ 1.200", "1.200,50" → "R$ 1.200"
function reais(s){ const n = Number(String(s || "").replace(/[^\d,]/g, "").replace(",", ".")); return n ? "R$ " + Math.round(n).toLocaleString("pt-BR") : ""; }
function dinheiroTexto(v){
  if (!v) return "";
  if (v >= 1e6) { const m = v / 1e6; return "R$ " + m.toLocaleString("pt-BR", {maximumFractionDigits: m >= 10 ? 1 : 2}) + (m < 2 ? " milhão" : " milhões"); }
  return "R$ " + Math.round(v / 1e3) + " mil";
}

// de onde veio o imóvel: lançamento do DWV, terceiros do DWV, Tabela Zero do DWV ou Top 3
const ORIGENS = {dwv: "DWV", dwv3: "DWV terceiros", zero: "Tabela Zero", top3: "Top 3"};
const origemDe = (it) => it.f === "top3" ? "top3" : it.sub === "terceiros" ? "dwv3" : it.sub === "zero" ? "zero" : "dwv";
const ehLancamento = (it) => it.f === "dwv" && it.sub !== "terceiros";
const tagOrigem = (it) => `<i class="fonte-tag ${origemDe(it)}">${ORIGENS[origemDe(it)]}</i>`;

// ---------- lista
function aoMudarImoveis(){
  prepararMar(() => { if (aba === "emp" && !atual) renderEmp(); if (!atual) renderSugestao(); });
  const n = todosImoveis().length;
  $("nE").textContent = n || "";
  preencherCidades();
  if (aba === "emp" && !atual) renderEmp();
  renderStatusEmp();
}
function renderStatusEmp(){
  const el = $("empStatus"); if (!el) return;
  const linha = (f) => {
    const F = FONTES[f], n = IMOVEIS[f].length, q = IMOVEIS.quando[f];
    if (IMOVEIS.baixando[f]) return `<span class="carregando">${F.nome}: atualizando…</span>`;
    if (IMOVEIS.erro[f]) return `<span class="erro">${F.nome}: ${esc(IMOVEIS.erro[f])}</span>`;
    const conta = f === "dwv" ? ["novos", "terceiros", "zero"].map((k) => [k, IMOVEIS.dwv.filter((x) => (x.sub || "novos") === k).length])
      .map(([k, c]) => `${c} ${k === "novos" ? "lançamentos" : k === "terceiros" ? "terceiros" : "Tabela Zero"}`).join(" · ") : n;
    return `<span>${F.nome}: ${conta} ${q ? "· " + haQuanto(q).replace("hoje", "atualizado hoje") : ""}</span>`;
  };
  el.innerHTML = linha("dwv") + linha("top3") + `<button type="button" class="x" data-atualizar-emp title="Baixar de novo dos sites">↻</button>`;
}
// ---------- filtros (iguais aos do DWV e do Top 3, num painel só)
const FILTRO0 = () => ({mar: new Set(), fonte: new Set(), cid: "", bairro: "", tipo: new Set(), fase: new Set(), mob: new Set(), qt: 0, s: 0, vg: 0,
  pMin: 0, pMax: 0, aMin: 0, aMax: 0, extras: new Set(), ordem: "combina"});
let FE = FILTRO0();
const OP = {
  fonte: [["dwv", "DWV lançamentos"], ["dwv3", "DWV terceiros"], ["zero", "Tabela Zero"], ["top3", "Top 3"]],
  tipo: ["Apartamento", "Casa", "Cobertura/Duplex", "Studio/Flat", "Sala comercial", "Terreno"].map((t) => [t, t]),
  fase: [["planta", "Lançamento / na planta"], ["obras", "Em obras"], ["pronto", "Pronto pra morar"]],
  mob: [["mobiliado", "Mobiliado"], ["semimobiliado", "Semimobiliado"], ["sem mobília", "Sem mobília"]],
  mar: [["frente", "Frente mar"], ["quadra", "Quadra mar"], ["mar", "Vista pro mar"]],
  extras: [["fin", "Aceita financiamento"], ["permuta", "Aceita permuta"], ["veiculo", "Aceita veículo"], ["promo", "Em promoção"]],
};
const SO_TOP3 = new Set(["mar", "fin", "permuta", "veiculo"]);
const PRECOS = [300e3, 500e3, 700e3, 900e3, 1e6, 1.3e6, 1.5e6, 2e6, 2.5e6, 3e6, 4e6, 5e6, 7e6, 10e6];
const AREAS = [30, 40, 50, 60, 70, 80, 100, 120, 150, 200, 250, 300, 400];
const ROT_N = {qt: "quarto", s: "suíte", vg: "vaga"};

function montarPainelFiltros(){
  const chips = (g, ops) => `<div class="chips" data-grupo="${g}">${ops.map(([v, t]) => `<button type="button" class="f" data-fv="${esc(v)}">${esc(t)}${SO_TOP3.has(v) ? ' <i class="so">Top 3</i>' : ""}</button>`).join("")}</div>`;
  const seg = (g) => `<div class="seg" data-grupo="${g}">${[0, 1, 2, 3, 4, 5].map((n) => `<button type="button" data-fv="${n}">${n ? n + "+" : "Tanto faz"}</button>`).join("")}</div>`;
  const sel = (id, lista, fmt, rot) => `<select id="${id}"><option value="0">${rot}</option>${lista.map((v) => `<option value="${v}">${fmt(v)}</option>`).join("")}</select>`;
  $("painelFiltros").innerHTML = `
    <div class="grupo"><b>Onde</b><div class="dupla"><select id="eCidade"><option value="">Todas as cidades</option></select><select id="eBairro"><option value="">Todos os bairros</option></select></div></div>
    <div class="grupo"><b>Site</b>${chips("fonte", OP.fonte)}</div>
    <div class="grupo"><b>Tipo de imóvel</b>${chips("tipo", OP.tipo)}</div>
    <div class="grupo"><b>Mar</b>${chips("mar", OP.mar)}<p class="nota">Frente mar = até ${FRENTE_M} m da água; quadra mar = até ${QUADRA_M} m (inclui frente mar). Medido pelo mapa (© OpenStreetMap), é aproximado: o nome do imóvel dizendo "frente mar" vale mais. Vista pro mar vem do Top 3.</p></div>
    <div class="grupo"><b>Fase</b>${chips("fase", OP.fase)}</div>
    <div class="grupo"><b>Quartos</b>${seg("qt")}</div>
    <div class="grupo"><b>Suítes</b>${seg("s")}</div>
    <div class="grupo"><b>Vagas de garagem</b>${seg("vg")}</div>
    <div class="grupo"><b>Preço</b><div class="dupla">${sel("pMin", PRECOS, dinheiroCurto, "Mínimo")}${sel("pMax", PRECOS, dinheiroCurto, "Máximo")}</div></div>
    <div class="grupo"><b>Área privativa</b><div class="dupla">${sel("aMin", AREAS, (v) => v + " m²", "Mínima")}${sel("aMax", AREAS, (v) => v + " m²", "Máxima")}</div></div>
    <div class="grupo"><b>Mobília</b>${chips("mob", OP.mob)}</div>
    <div class="grupo"><b>Mais filtros</b>${chips("extras", OP.extras)}</div>
    <div class="pf-rodape"><button type="button" class="btn sec" data-limpar-filtros>Limpar tudo</button><button type="button" class="btn" data-fechar-filtros id="verN">Ver imóveis</button></div>`;
  ["eCidade", "eBairro", "pMin", "pMax", "aMin", "aMax"].forEach((id) => $(id).addEventListener("change", () => {
    const v = $(id).value;
    if (id === "eCidade") { FE.cid = v; FE.bairro = ""; }
    else if (id === "eBairro") FE.bairro = v; else FE[id] = Number(v) || 0;
    filtroMudou();
  }));
}
function sincronizarPainel(){
  document.querySelectorAll("#painelFiltros [data-grupo]").forEach((g) => {
    const k = g.dataset.grupo;
    g.querySelectorAll("[data-fv]").forEach((b) => {
      const v = b.dataset.fv;
      const on = FE[k] instanceof Set ? FE[k].has(v) : String(FE[k]) === v;
      b.setAttribute("aria-pressed", String(on));
    });
  });
  preencherCidades(); preencherBairros();
  ["pMin", "pMax", "aMin", "aMax"].forEach((id) => { $(id).value = String(FE[id] || 0); });
  $("eOrdem").value = FE.ordem;
}
function preencherCidades(){
  const sel = $("eCidade"); if (!sel) return;
  const cont = {};
  todosImoveis().forEach((it) => { const c = cidadeCanon(it.cidade); if (c) cont[c] = (cont[c] || 0) + 1; });
  const html = `<option value="">Todas as cidades</option>` + Object.entries(cont).sort((a, b) => b[1] - a[1]).map(([c, k]) => `<option value="${esc(c)}">${esc(c)} (${k})</option>`).join("");
  if (sel.dataset.h !== html) { sel.innerHTML = html; sel.dataset.h = html; }
  sel.value = FE.cid;
}
function preencherBairros(){
  const sel = $("eBairro"); if (!sel) return;
  const cont = {};
  todosImoveis().forEach((it) => { if (it.bairro && (!FE.cid || cidadeCanon(it.cidade) === FE.cid)) { const b = it.bairro.trim(); cont[b] = (cont[b] || 0) + 1; } });
  const html = `<option value="">${FE.cid ? "Todos os bairros" : "Bairro (escolha a cidade)"}</option>` + Object.entries(cont).sort((a, b) => a[0].localeCompare(b[0])).map(([c, k]) => `<option value="${esc(c)}">${esc(c)} (${k})</option>`).join("");
  if (sel.dataset.h !== html) { sel.innerHTML = html; sel.dataset.h = html; }
  sel.value = FE.bairro; sel.disabled = !FE.cid;
}
function contarFiltros(f){
  return f.mar.size + f.fonte.size + (f.cid ? 1 : 0) + (f.bairro ? 1 : 0) + f.tipo.size + f.fase.size + f.mob.size + f.extras.size +
    (f.qt ? 1 : 0) + (f.s ? 1 : 0) + (f.vg ? 1 : 0) + (f.pMin || f.pMax ? 1 : 0) + (f.aMin || f.aMax ? 1 : 0);
}
function ativosHTML(){
  const c = [];
  const chip = (txt, acao) => c.push(`<button type="button" class="ativo" data-tirar="${esc(acao)}">${esc(txt)} <span>✕</span></button>`);
  FE.fonte.forEach((v) => chip(ORIGENS[v], "fonte:" + v));
  if (FE.cid) chip(FE.cid, "cid"); if (FE.bairro) chip(FE.bairro, "bairro");
  FE.tipo.forEach((v) => chip(v, "tipo:" + v));
  FE.mar.forEach((v) => chip(OP.mar.find((o) => o[0] === v)[1], "mar:" + v));
  FE.fase.forEach((v) => chip(OP.fase.find((o) => o[0] === v)[1], "fase:" + v));
  ["qt", "s", "vg"].forEach((k) => { if (FE[k]) chip(`${FE[k]}+ ${ROT_N[k]}${FE[k] > 1 ? "s" : ""}`, k); });
  if (FE.pMin || FE.pMax) chip(FE.pMin && FE.pMax ? `${dinheiroCurto(FE.pMin)} a ${dinheiroCurto(FE.pMax)}` : FE.pMin ? `desde ${dinheiroCurto(FE.pMin)}` : `até ${dinheiroCurto(FE.pMax)}`, "preco");
  if (FE.aMin || FE.aMax) chip(FE.aMin && FE.aMax ? `${FE.aMin} a ${FE.aMax} m²` : FE.aMin ? `${FE.aMin}+ m²` : `até ${FE.aMax} m²`, "area");
  FE.mob.forEach((v) => chip(OP.mob.find((o) => o[0] === v)[1], "mob:" + v));
  FE.extras.forEach((v) => chip(OP.extras.find((o) => o[0] === v)[1], "extras:" + v));
  return c.join("");
}
function tirarFiltro(acao){
  const [k, v] = acao.split(":");
  if (v !== undefined) FE[k].delete(v);
  else if (k === "preco") { FE.pMin = 0; FE.pMax = 0; }
  else if (k === "area") { FE.aMin = 0; FE.aMax = 0; }
  else if (k === "cid") { FE.cid = ""; FE.bairro = ""; }
  else FE[k] = typeof FE[k] === "number" ? 0 : "";
  filtroMudou();
}
function clicarFiltro(btn){
  const g = btn.closest("[data-grupo]").dataset.grupo, v = btn.dataset.fv;
  if (FE[g] instanceof Set) { FE[g].has(v) ? FE[g].delete(v) : FE[g].add(v); }
  else FE[g] = Number(v);
  filtroMudou();
}
function filtroMudou(){ empMostrar = 60; sincronizarPainel(); renderEmp(); }

function filtrarEmp(f, q){
  const esconder = $("esconder").checked && contato.chave;
  const qn = norm(q || "");
  const ate = (par) => par[1] ?? par[0];
  const r = todosImoveis().filter((it) => {
    if (f.fonte.size && !f.fonte.has(origemDe(it))) return false;
    if (f.cid && cidadeCanon(it.cidade) !== f.cid) return false;
    if (f.bairro && (it.bairro || "").trim() !== f.bairro) return false;
    if (f.tipo.size && !f.tipo.has(it.tipo)) return false;
    // mar: vale qualquer uma das marcadas (frente OU quadra OU vista)
    if (f.mar.size && ![...f.mar].some((m) => m === "frente" ? it.frente : m === "quadra" ? it.quadra : (it.mar || it.frente))) return false;
    if (f.fase.size && !f.fase.has(it.fase)) return false;
    if (f.mob.size && !f.mob.has(it.mob)) return false;
    if (f.qt && !(ate(it.q) >= f.qt)) return false;
    if (f.s && !(it.s >= f.s)) return false;
    if (f.vg && !(ate(it.vg) >= f.vg)) return false;
    if (f.pMin && !(it.p >= f.pMin)) return false;
    if (f.pMax && !(it.p && it.p <= f.pMax)) return false;
    if (f.aMin && !(ate(it.a) >= f.aMin)) return false;
    if (f.aMax && !(it.a[0] != null && it.a[0] <= f.aMax)) return false;
    for (const x of f.extras) if (!it[x]) return false;
    if (qn && !norm([it.nome, it.constr, it.bairro, it.cidade, it.rua, it.tipo, it.un].join(" ")).includes(qn)) return false;
    if (esconder && jaRecebeu("e", it.id)) return false;
    return true;
  });
  const pr = (it) => it.p || Infinity;
  if (f.ordem === "combina" && procuraAtual) {
    const pts = new Map(r.map((it) => [it.id, combina(it, procuraAtual)]));
    return r.filter((it) => pts.get(it.id).ok).sort((a, b) => pts.get(b.id).pts - pts.get(a.id).pts || pr(a) - pr(b));
  }
  if (f.ordem === "precoD") r.sort((a, b) => (b.p || 0) - (a.p || 0));
  else if (f.ordem === "novo") r.sort((a, b) => String(b.up).localeCompare(String(a.up)));
  else if (f.ordem === "area") r.sort((a, b) => (ate(b.a) || 0) - (ate(a.a) || 0));
  else r.sort((a, b) => pr(a) - pr(b));
  return r;
}
function itemEmp(it, mini, motivo, cb){
  const foto = fotoDe(it, 160);
  const nome = it.nome + (it.un ? ` · un. ${it.un}` : "") + (it.comp && !mini ? ` · ${it.comp}` : "");
  if (!cb && FE.ordem === "combina" && procuraAtual && !mini) cb = combina(it, procuraAtual);
  const linha = [cidadeCanon(it.cidade) + (it.bairro ? " · " + it.bairro : ""), quartosTxt(it), it.s ? it.s + (it.s > 1 ? " suítes" : " suíte") : "", faixa(it.a, " m²")].filter(Boolean).join(" · ");
  const preco = it.p ? (ehLancamento(it) ? "a partir de " : "") + dinheiroTexto(it.p) : "preço sob consulta";
  const fase = {planta: "Na planta", obras: it.prog ? `Em obras ${it.prog}%` : "Em obras", pronto: it.mob ? it.mob.charAt(0).toUpperCase() + it.mob.slice(1) : "Pronto"}[it.fase] || "";
  const selos = [fase, it.frente ? "Frente mar" : it.quadra ? "Quadra mar" : "", it.mar && !it.frente && "Vista mar", it.promo && "Promoção"].filter(Boolean).map((t) => `<i class="selo-f">${esc(t)}</i>`).join("");
  return `<button class="item emp${mini ? " mini" : ""}" type="button" data-abrir="${esc(it.id)}" data-tipo="e"${motivo ? ` data-motivo="${esc(motivo)}"` : ""}>
    ${foto ? `<img class="foto-n" src="${esc(foto)}" alt="" loading="lazy">` : `<span class="foto-n vazio-f"></span>`}
    <span><b>${esc(nome)}</b><small>${esc(linha)}</small>${mini ? "" : `<small class="selos">${selos}</small>`}<small class="preco">${esc(preco)} ${tagOrigem(it)}</small>${cb && cb.ok ? `<small class="combina"><b>${cb.pts}%</b> ${esc(cb.motivos.slice(0, 7).join(" · "))}${cb.faltas.length ? `<em> · ${esc(cb.faltas.slice(0, 2).join(", "))}</em>` : ""}</small>` : ""}${marcaEnviado("e", it.id)}</span></button>`;
}
function renderEmp(){
  if (!$("eCidade")) { montarPainelFiltros(); sincronizarPainel(); }
  renderProcura();
  const lista = filtrarEmp(FE, $("busca").value.trim());
  const n = contarFiltros(FE);
  $("nFiltros").textContent = n ? n : ""; $("abreFiltros").classList.toggle("tem", !!n);
  $("ativos").innerHTML = ativosHTML() + (n ? `<button type="button" class="link" data-limpar-filtros>Limpar</button>` : "");
  const verN = $("verN"); if (verN) verN.textContent = lista.length ? `Ver ${lista.length} imóve${lista.length > 1 ? "is" : "l"}` : "Nenhum imóvel";
  const base = todosImoveis();
  let html;
  if (!base.length) html = `<p class="vazio">${IMOVEIS.baixando.dwv || IMOVEIS.baixando.top3 ? "Baixando os empreendimentos do DWV e do Top 3… (a primeira vez leva até 1 minuto)" : "Nenhum empreendimento guardado ainda. Clique em ↻."}</p>`;
  else if (!lista.length) html = `<p class="vazio">Nada com esses filtros.<br><button type="button" class="link" data-limpar-filtros>Limpar os filtros</button></p>`;
  else html = `<p class="conta">${lista.length} imóve${lista.length > 1 ? "is" : "l"}</p>` + lista.slice(0, empMostrar).map((it) => itemEmp(it)).join("") +
    (lista.length > empMostrar ? `<button class="btn sec mais" type="button" data-mais-emp>Mostrar mais ${Math.min(60, lista.length - empMostrar)}</button>` : "");
  $("lista").innerHTML = html;
}
function renderProcura(){
  const el = $("procura");
  procuraAtual = contato.conversa && contato.conversa.length ? oQueProcura(contato.conversa) : null;
  if (!procuraAtual) { el.innerHTML = ""; return; }
  const nome = primeiroNome(contato.nome) || contato.nome;
  el.innerHTML = `<div class="procura">Pelo que ${esc(nome)} escreveu: <b>${esc(descreverProcura(procuraAtual))}</b> <button type="button" class="link" data-aplicar-procura>Filtrar assim</button></div>`;
}
// vira filtro só o que é eliminatório (cidade, tipo, quartos, orçamento máximo); bairro, vagas, suítes, vista mar
// e fase entram na ORDEM (o que mais combina vem primeiro), pra não sumir opção boa por um detalhe
function filtroDaProcura(p){
  const f = FILTRO0();
  if (!p) return f;
  if (p.cidades && p.cidades.length === 1) f.cid = cidadeCanon(p.cidades[0]);
  (p.tipos || []).forEach((t) => f.tipo.add(t));
  if (p.tipos && p.tipos.includes("Apartamento")) f.tipo.add("Cobertura/Duplex");
  if (p.quartos) f.qt = Math.min(5, p.quartos);
  if (p.ate) f.pMax = PRECOS.find((a) => a >= p.ate) || 0;
  f.ordem = "combina";
  return f;
}
function aplicarProcura(p){ if (!p) return; FE = filtroDaProcura(p); filtroMudou(); }
// sugestão de empreendimento dentro da análise da conversa
function blocoEmpSugestao(){
  const p = contato.conversa && contato.conversa.length ? oQueProcura(contato.conversa) : null;
  if (!p || !todosImoveis().length) return "";
  procuraAtual = p;
  const lista = todosImoveis().filter((it) => !jaRecebeu("e", it.id)).map((it) => ({it, c: combina(it, p)})).filter((o) => o.c.ok)
    .sort((a, b) => b.c.pts - a.c.pts || (a.it.p || 9e12) - (b.it.p || 9e12));
  if (!lista.length) return `<div class="assunto"><div class="ass-topo"><b>Imóvel ideal pra ele</b></div><p class="trecho">${esc(descreverProcura(p))}</p><p class="dica">Nada nos sites bate com tudo isso. Abra a aba Imóveis e afrouxe um filtro.</p></div>`;
  const motivo = `ele procura ${descreverProcura(p)}`;
  return `<div class="assunto ideal"><div class="ass-topo"><b>Imóvel ideal pra ele</b><span class="vezes">${lista.length} combinam</span></div><p class="perfil">${esc(descreverProcura(p))}</p>` +
    lista.slice(0, 5).map((o) => itemEmp(o.it, true, motivo, o.c)).join("") +
    `<button type="button" class="link" data-ver-procura>Ver os ${lista.length} na aba Imóveis, do que mais combina pro que menos</button></div>`;
}
// ---------- ficha
const DESTAQUES = ["Frente mar", "Vista mar", "Pé na areia", "Mobiliado", "Decorado", "Sol da manhã", "Piscina", "Rooftop", "Churrasqueira", "Lavabo", "Hidromassagem", "Andar alto", "Cobertura", "Dependência"];
function destaquesDe(texto){
  const t = norm(texto || "");
  return DESTAQUES.filter((d) => t.includes(norm(d))).slice(0, 4);
}
async function abrirEmp(id){
  const it = todosImoveis().find((x) => x.id === id); if (!it) return;
  if (atual && atual.tipo === "v") $("player").pause();
  atual = {tipo: "e", it: {...it, slug: it.id, titulo: it.nome}};
  $("ePor").innerHTML = motivoAtual ? `<div class="por">Sugerido porque ${esc(motivoAtual)} <button type="button" class="link" data-voltar>Voltar à análise</button></div>` : "";
  $("navegar").hidden = true; $("sugestao").hidden = true; $("ficha").hidden = true; $("fichaN").hidden = true; $("fichaE").hidden = false;
  const foto = fotoDe(it, 900);
  const preco = it.p ? (ehLancamento(it) ? "A partir de " : "") + real(it.p) : "Preço sob consulta";
  $("eCartao").innerHTML = `${foto ? `<img src="${esc(foto)}" alt="">` : ""}<span class="c-txt"><b>${esc(it.nome)}${it.un ? ` <em>un. ${esc(it.un)}</em>` : ""}</b>
    <small>${tagOrigem(it)}<span>${esc([it.constr, ondeFica({...it, cidade: cidadeCanon(it.cidade)})].filter(Boolean).join(" · "))}</span></small>
    <span class="preco-g">${esc(preco)}</span></span>`;
  const dados = [quartosTxt(it), it.s ? it.s + (it.s > 1 ? " suítes" : " suíte") : "", faixa(it.vg) ? faixa(it.vg) + " vaga" + (faixa(it.vg) === "1" ? "" : "s") : "",
    faixa(it.a, " m²"), it.frente ? "Frente mar" : it.quadra ? "Quadra mar" : "", it.dm != null && it.dm < 3000 ? `~${it.dm < 1000 ? Math.round(it.dm / 10) * 10 + " m" : (it.dm / 1000).toLocaleString("pt-BR", {maximumFractionDigits: 1}) + " km"} da praia` : "",
    it.tipo && it.f === "top3" ? it.tipo : "", entregaTxt(it), it.prog != null && it.f === "dwv" && it.prog > 0 && it.prog < 100 ? `obra ${it.prog}%` : "", it.rua].filter(Boolean);
  $("eDados").innerHTML = dados.map((d) => `<span class="dado">${esc(d)}</span>`).join("");
  $("eFotos").innerHTML = ""; $("eInterno").innerHTML = ""; $("eDescBox").hidden = true;
  const ter = it.sub === "terceiros";
  if (it.f === "dwv") {
    $("eTitMsg").textContent = "Fotos + mensagem + link";
    $("eDica").innerHTML = (ter ? "<b>[link]</b> vira a página do imóvel no DWV (fotos, valor e condições)" : "<b>[link]</b> vira o hotsite do empreendimento no DWV") +
      ", com o nome e o contato de quem está logado no DWV. As fotos marcadas vão junto e o texto vira a legenda. Sem foto marcada, vai só o texto e o WhatsApp mostra a prévia do link.";
  } else {
    $("eTitMsg").textContent = "Fotos + mensagem";
    $("eDica").textContent = "O link do Top 3 pede login, então o cliente recebe as fotos com o texto. O nome do agenciador nunca vai.";
  }
  const det0 = detalheEmp[it.id];
  renderMsgsEmp(det0 || null);
  if (det0) { renderExtraEmp(it, det0); renderFotosEmp(det0); }
  else {
    $("eFotos").innerHTML = `<p class="dica carregando">Buscando as fotos…</p>`;
    // fotos primeiro (o Top 3 tem a galeria pública); descrição e pagamento chegam depois, sem travar as fotos
    const det = {fotos: [], plantas: []};
    const pedidoFicha = it.f === "dwv" ? noSite("dwv", dwvFicha, [it.id, ter, it.p]) : noSite("top3", top3Ficha, [it.link]);
    if (it.f === "top3") {
      det.fotos = await top3Fotos(it.wp).catch(() => []);
      if (!atual || atual.it.id !== it.id) return;
      renderFotosEmp(det, "Buscando a descrição e a forma de pagamento…");
    }
    const r = await pedidoFicha.catch((e) => ({erro: String(e.message || e)}));
    if (!atual || atual.it.id !== it.id) return;
    if (r && !r.erro) Object.assign(det, r, it.f === "top3" ? {fotos: det.fotos} : {});
    det.erro = r && r.erro || "";
    if (!det.erro) {
      detalheEmp[it.id] = det;
      // o bairro que o DWV mandou fica no imóvel (melhora a sugestão pela conversa)
      if (det.bairro && !it.bairro) { const b = titulo(det.bairro); it.bairro = b; atual.it.bairro = b; }
    }
    renderExtraEmp(it, det);
    if (it.f !== "top3" || !document.querySelector("#eFotos [data-foto]")) renderFotosEmp(det);   // no Top 3 a galeria já está na tela: não desfaz o que foi marcado
    else { const d = document.querySelector("#eFotos .dica:last-child"); if (d) d.textContent = "Marque até 10. Toque na foto pra marcar ou desmarcar; ⤢ abre grande."; }
    renderMsgsEmp(det.erro ? null : det);
  }
  mostrarJa(); window.scrollTo(0, 0);
}
function renderExtraEmp(it, det){
  if (det.erro) {
    const site = it.f === "dwv" ? "DWV (app.dwvapp.com.br)" : "Top 3 (top3agenciamentos.com.br)";
    $("eInterno").innerHTML = `<div class="aviso">${det.erro === "login" ? `Entre no ${site} neste Chrome pra trazer a descrição e a forma de pagamento.` : esc(det.erro)} <button type="button" class="link" data-reabrir-emp>Tentar de novo</button></div>`;
    return;
  }
  const extra = [];
  if (it.f === "top3") {
    extra.push(det.suites && det.suites !== "0" ? det.suites + " suítes" : "", det.fase, det.entrega && "entrega " + det.entrega, det.construtora,
      reais(det.condominio) && "cond. " + reais(det.condominio), reais(det.iptu) && "IPTU " + reais(det.iptu));
  } else {
    extra.push(det.bairro && titulo(det.bairro), det.condominio ? "cond. " + reais(det.condominio) : "", det.iptu ? "IPTU " + reais(det.iptu) : "");
  }
  $("eDados").insertAdjacentHTML("beforeend", extra.filter(Boolean).map((d) => `<span class="dado">${esc(d)}</span>`).join(""));
  const so = [];
  if (it.f === "top3") {
    if (det.agenciador) so.push(`<span>Agenciador: ${esc(det.agenciador)}</span>`);
    (det.pagamento || []).filter((p) => !/^entrada|\bx\b|parcel|financ|a vista|à vista|saldo/i.test(p)).forEach((n) => so.push(`<span>${esc(n)}</span>`));
    so.push(`<a href="${esc(it.link)}" target="_blank" rel="noopener">Abrir no Top 3</a>`);
  } else {
    if (det.comissao) so.push(`<span>Comissão: ${esc(String(det.comissao))}%</span>`);
    if (it.sub === "terceiros" && it.constr) so.push(`<span>Anunciado por: ${esc(it.constr)}</span>`);
    if (it.sub !== "terceiros") so.push(`<a href="https://material.dwvapp.com.br/print/redevelopmentpdf/${esc(it.id.replace(/-/g, ""))}/${encodeURIComponent(it.nome)}.pdf" target="_blank" rel="noopener">Tabela de unidades e preços (PDF do DWV)</a>`);
  }
  $("eInterno").innerHTML = so.length ? `<div class="interno"><b>Só pra você</b>${so.join("")}</div>` : "";
  const desc = it.f === "top3" ? det.descricao : [det.unidade && det.unidade.length ? "IMÓVEL\n" + det.unidade.join("\n") : "", det.lazer && det.lazer.length ? "LAZER E ESTRUTURA\n" + det.lazer.join("\n") : "",
    det.pagamento && det.pagamento.length ? "PAGAMENTO\n" + det.pagamento.join("\n") : ""].filter(Boolean).join("\n\n");
  if (desc) { $("eDesc").textContent = desc; $("eDescBox").hidden = false; }
}
const titulo = (s) => String(s || "").toLowerCase().replace(/(^|\s)\S/g, (c) => c.toUpperCase());

// ---------- galeria: escolher as fotos (e plantas) que vão; cada foto marcada já começa a baixar
const FOTO_PRONTA = new Map();   // url → Promise<dataURL>
function baixarFoto(u){
  if (!FOTO_PRONTA.has(u)) {
    const pr = fotoParaZap(u);
    FOTO_PRONTA.set(u, pr);
    pr.then(() => marcarFoto(u, "ok"), () => { FOTO_PRONTA.delete(u); marcarFoto(u, "erro"); });
    marcarFoto(u, "baixando");
  }
  return FOTO_PRONTA.get(u);
}
function marcarFoto(u, est){ document.querySelectorAll(`[data-foto="${CSS.escape(u)}"]`).forEach((i) => { i.closest(".ft").dataset.est = est; }); contarFotos(); }
function renderFotosEmp(det, aviso){
  const grade = (lista, rotulo, marcadas) => lista.length ? `<h3>${rotulo}</h3><div class="galeria">` + lista.map((f, i) =>
    `<label class="ft"><input type="checkbox" data-foto="${esc(f.g)}"${i < marcadas ? " checked" : ""}><img src="${esc(f.t)}" alt="" loading="lazy" onerror="this.onerror=null;this.src='${esc(f.g)}'"><button type="button" class="lupa" data-ver-foto="${esc(f.g)}" title="Ver grande">⤢</button><i class="est"></i></label>`).join("") + `</div>` : "";
  const fotos = det.fotos || [], plantas = det.plantas || [];
  if (!fotos.length && !plantas.length) { $("eFotos").innerHTML = det.erro ? "" : `<p class="dica">${aviso ? esc(aviso) : "Esse imóvel não tem fotos no site."}</p>`; return; }
  $("eFotos").innerHTML = `<div class="fotos-topo"><b>Fotos que vão junto</b><span id="nFotos"></span><button type="button" class="link" data-fotos="todas">marcar 10</button><button type="button" class="link" data-fotos="nenhuma">nenhuma</button></div>` +
    grade(fotos, `Fotos (${fotos.length})`, 5) + grade(plantas, `Plantas (${plantas.length})`, 0) +
    `<p class="dica">Marque até 10. Toque na foto pra marcar ou desmarcar; ⤢ abre grande.${aviso ? " " + esc(aviso) : ""}</p>`;
  fotosMarcadas().forEach((u) => baixarFoto(u).then(() => marcarFoto(u, "ok"), () => {}));
  contarFotos();
}
function contarFotos(){
  const marc = fotosMarcadas(), el = $("nFotos"); if (!el) return;
  const prontas = marc.filter((u) => document.querySelector(`[data-foto="${CSS.escape(u)}"]`)?.closest(".ft")?.dataset.est === "ok").length;
  el.textContent = marc.length ? `${marc.length} marcada${marc.length > 1 ? "s" : ""} · ${prontas === marc.length ? "prontas pra enviar" : `baixando ${prontas}/${marc.length}`}` : "nenhuma (vai só o texto)";
  const lim = marc.length >= 10;
  document.querySelectorAll("[data-foto]").forEach((i) => { if (!i.checked) i.disabled = lim; });
}
function fotosMarcadas(){ return [...document.querySelectorAll("[data-foto]:checked")].map((i) => i.dataset.foto).slice(0, 10); }
function verFoto(u){
  const ov = document.createElement("div"); ov.className = "lightbox";
  ov.innerHTML = `<img src="${esc(u)}" alt=""><button type="button" class="x-fechar" title="Fechar">✕</button>`;
  ov.addEventListener("click", () => ov.remove()); document.body.appendChild(ov);
}

// ---------- mensagens (o motivo é o que o CLIENTE disse; sem travessão, sem "caro")
function msgsEmp(it, det){
  const p = contato.conversa && contato.conversa.length ? oQueProcura(contato.conversa) : null;
  const cid = cidadeCanon(it.cidade);
  const bairro = it.bairro || (det && det.bairro ? titulo(det.bairro) : "");
  const onde = [bairro, cid].filter(Boolean).join(", ");
  // destaques de lazer (DWV): "Lazer com piscina, academia e espaço gourmet."
  const LAZ = ["Piscina", "Academia", "Espaço gourmet", "Rooftop", "Sauna", "Playground", "Salão de festas", "Quadra", "Spa", "Cinema", "Coworking", "Pet place"];
  const laz = det && det.lazer ? LAZ.filter((x) => det.lazer.some((l) => norm(l).includes(norm(x)))).slice(0, 4).map((x) => x.toLowerCase()) : [];
  const lazer = laz.length ? `Lazer com ${laz.length > 1 ? laz.slice(0, -1).join(", ") + " e " + laz.slice(-1) : laz[0]}.` : "";
  const pagDwv = det && det.f !== "top3" && det.pagamento && det.pagamento.length && it.f === "dwv" ? det.pagamento.map((x) => "• " + x).join("\n") : "";
  const q = quartosTxt(it), area = faixa(it.a, " m²");
  const atende = pedidoAtendido(it, p), bate = !!atende;
  const gancho = bate ? `Você me falou que procura ${procuraFalada(atende)}, então separei` : "Separei";
  if (it.sub === "terceiros") {
    const tipoT = (it.tipo || "imóvel").split("/")[0].toLowerCase();
    const sts = it.s ? `${it.s} suíte${it.s > 1 ? "s" : ""}` : "";
    const vgs = faixa(it.vg) ? `${faixa(it.vg)} vaga${faixa(it.vg) === "1" ? "" : "s"}` : "";
    const specs = [q, sts, area, vgs].filter(Boolean).join(", ");
    const valor = it.p ? `por ${dinheiroTexto(it.p)}` : "";
    const linha = [specs, valor].filter(Boolean).join(", ");
    const Linha = linha ? linha.charAt(0).toUpperCase() + linha.slice(1) + "." : "";
    return [
      {rot: "Apresentar o imóvel", t: `Oi {nome}! ${gancho} ${tipoT === "casa" ? "uma casa" : tipoT === "sala comercial" ? "uma sala comercial" : "um " + tipoT} pra você: ${it.nome}, em ${onde}.\n${Linha}${lazer ? " " + lazer : ""}${pagDwv ? "\n\nCondição de pagamento:\n" + pagDwv : ""}\n\nAqui tem todas as fotos e os detalhes: [link]\n\nQuer marcar uma visita pra ver de perto?`},
      {rot: "Mais uma opção", t: `{nome}, achei mais uma opção que vale você ver: ${it.nome}, em ${onde}. ${Linha}\n\nTá tudo aqui: [link]\n\nO que achou?`},
      {rot: "Lead frio", t: `Oi {nome}, tudo bem? Entrou uma unidade em ${cid} que ${bate ? "tem a ver com o que você procurava" : "vale você conhecer"}: ${it.nome}${specs ? ", " + specs : ""}.\n\nDá uma olhada sem compromisso: [link]`},
    ];
  }
  if (it.f === "dwv") {
    const specs = [q, area].filter(Boolean).join(", ");
    const preco = it.p ? `a partir de ${dinheiroTexto(it.p)}` : "";
    const ent = entregaTxt(it);
    const linha = [specs, preco, ent && ent !== "pronto" ? ent : ent === "pronto" ? "pronto pra morar" : ""].filter(Boolean).join(", ");
    return [
      {rot: "Apresentar o empreendimento", t: `Oi {nome}! ${gancho} um empreendimento pra você: o ${it.nome}, em ${onde}${it.constr ? ", da " + it.constr : ""}.\n${linha ? linha.charAt(0).toUpperCase() + linha.slice(1) + "." : ""}${lazer ? " " + lazer : ""}\n\nMontei uma página com fotos, plantas e localização pra você ver com calma: [link]\n\nQuer que eu te mande os valores das unidades disponíveis?`},
      {rot: "Mais uma opção", t: `{nome}, achei mais uma opção que vale você ver: ${it.nome}, em ${onde}. ${linha ? linha.charAt(0).toUpperCase() + linha.slice(1) + "." : ""}\n\nTá tudo aqui: [link]\n\nO que achou?`},
      {rot: "Lead frio", t: `Oi {nome}, tudo bem? Tô com uma opção em ${cid} que ${bate ? "tem a ver com o que você procurava" : "vale você conhecer"}: ${it.nome}${specs ? ", " + specs : ""}.\n\nDá uma olhada sem compromisso: [link]`},
    ];
  }
  const tipo = (it.tipo || "imóvel").toLowerCase();
  const d = det || {};
  const suites = d.suites && d.suites !== "0" ? `${d.suites} suíte${d.suites === "1" ? "" : "s"}` : "";
  const vagas = faixa(it.vg) ? `${faixa(it.vg)} vaga${faixa(it.vg) === "1" ? "" : "s"}` : "";
  const l1 = [it.un ? "Unidade " + it.un : "", area, suites || q, vagas].filter(Boolean).join(", ");
  const dest = destaquesDe(d.descricao);
  const pag = (d.pagamento || []).find((x) => /entrada|\bx\b|parcel|financ|vista|saldo/i.test(x)) || "";
  const custo = [reais(d.condominio) && "condomínio " + reais(d.condominio), reais(d.iptu) && "IPTU " + reais(d.iptu)].filter(Boolean).join(", ");
  const linhas = [l1, dest.length && dest.join(", "), it.p && "Valor: " + real(it.p), pag && "Pagamento: " + pag, custo && custo.charAt(0).toUpperCase() + custo.slice(1)].filter(Boolean).map((l) => "• " + l).join("\n");
  return [
    {rot: "Apresentar o imóvel", t: `Oi {nome}! ${gancho} esse ${tipo} pra você: ${it.nome}, em ${onde}.\n\n${linhas}\n\nTe mandei as fotos aqui. Quer marcar uma visita pra ver de perto?`},
    {rot: "Mais uma opção", t: `{nome}, olha mais essa opção: ${it.nome}, em ${onde}. ${[l1, it.p && "por " + dinheiroTexto(it.p)].filter(Boolean).join(", ")}.\n\nO que achou das fotos?`},
    {rot: "Lead frio", t: `Oi {nome}, tudo bem? Entrou uma unidade em ${cid} que ${bate ? "tem a ver com o que você procurava" : "vale você conhecer"}: ${it.nome}${l1 ? ", " + l1 : ""}.\n\nTe mandei umas fotos. Se fizer sentido, te passo os detalhes.`},
  ];
}
function renderMsgsEmp(det){
  if (!atual || atual.tipo !== "e") return;
  const frio = paradaAgora() > 0;
  $("eMsgs").innerHTML = blocoMsgs(msgsEmp(atual.it, det), "", frio);
}

// ---------- colocar na conversa
async function linkGuardado(it){
  const chave = "dwvlink:" + (contato.chave || "-") + ":" + it.id;
  const g = await chrome.storage.local.get(chave);
  if (g[chave]) return {url: g[chave]};
  const r = await linkDWV(it, contato.nome || $("nome").value.trim());
  if (r.url) chrome.storage.local.set({[chave]: r.url});
  return r;
}
async function prepararTextoEmp(texto){
  const it = atual.it;
  texto = preencher(texto);
  if (it.f !== "dwv" || !texto.includes("[link]")) return {texto};
  const r = await linkGuardado(it);
  if (r.erro) return {erro: r.erro === "login" ? "Entre no DWV neste Chrome (app.dwvapp.com.br) pra criar o link do cliente." : r.erro};
  return {texto: texto.replaceAll("[link]", r.url)};
}
async function colocarEmp(botao, texto){
  const it = atual.it;
  botao.disabled = true; const antes = botao.textContent; botao.textContent = it.f === "dwv" ? "Criando o link…" : "Preparando as fotos…";
  try {
    const pt = await prepararTextoEmp(texto);
    if (pt.erro) return toast(pt.erro, 6000);
    copiar(pt.texto);
    let r;
    const sel = fotosMarcadas();
    if (!sel.length) r = await falarComZap({acao: "texto", texto: pt.texto});
    else {
      botao.textContent = `Preparando ${sel.length} foto${sel.length > 1 ? "s" : ""}…`;
      const arquivos = [];
      for (const [i, u] of sel.entries()) { try { arquivos.push({dataUrl: await baixarFoto(u), nome: `${it.nome.replace(/[^\p{L}\d]+/gu, "-")}-${i + 1}.jpg`, tipo: "image/jpeg"}); } catch (_) {} }
      if (!arquivos.length) return toast("Não consegui baixar as fotos. A mensagem está copiada: cole na conversa (⌘V).", 5000);
      botao.textContent = "Colocando…";
      r = await falarComZap({acao: "colocarArquivos", arquivos, texto: pt.texto});
    }
    if (r.erro === "sem-aba") return toast("Abra o WhatsApp Web (web.whatsapp.com) e a conversa do cliente.", 4500);
    if (r.erro === "recarregar") return toast("Recarregue a aba do WhatsApp (F5) uma vez e tente de novo.", 4500);
    if (!r.ok) return toast(r.erro || "Não deu certo. A mensagem está copiada.", 5000);
    registrar("e", it.id, it.nome); mostrarJa();
    if (r.linkOk === false) return toast("Atenção: o link não ficou inteiro na caixa do WhatsApp. Apague e cole de novo (⌘V): está copiado.", 7000);
    toast(!sel.length ? (r.escreveu ? "Pronto: mensagem e link na conversa. Espere a prévia e aperte Enter." : "A mensagem está copiada: clique na conversa e cole (⌘V).")
      : (r.legenda ? `Pronto: ${sel.length} foto${sel.length > 1 ? "s" : ""} e o texto na conversa. Confira e aperte Enter.` : "Fotos na conversa. Clique na legenda e cole (⌘V): o texto está copiado."), 5500);
  } finally { botao.disabled = false; botao.textContent = antes; }
}
async function copiarEmp(texto){
  const pt = await prepararTextoEmp(texto);
  if (pt.erro) return toast(pt.erro, 6000);
  toast(await copiar(pt.texto) ? "Copiado" + (atual.it.f === "dwv" ? " com o link do DWV" : "") : "Não consegui copiar");
}

// ---------- eventos próprios da aba
document.getElementById("eOrdem").addEventListener("change", (e) => { FE.ordem = e.target.value; empMostrar = 60; renderEmp(); });
document.addEventListener("click", (ev) => {
  const t = ev.target;
  const fv = t.closest("#painelFiltros [data-fv]"); if (fv) { clicarFiltro(fv); return; }
  const ti = t.closest("[data-tirar]"); if (ti) { tirarFiltro(ti.dataset.tirar); return; }
  if (t.closest("[data-limpar-filtros]")) { const o = FE.ordem; FE = FILTRO0(); FE.ordem = o; filtroMudou(); return; }
  if (t.closest("[data-fechar-filtros]")) { abrirFiltros(false); $("lista").scrollIntoView({block: "start", behavior: "smooth"}); return; }
  if (t.closest("#abreFiltros")) { abrirFiltros($("painelFiltros").hidden); return; }
});
function abrirFiltros(sim){ $("painelFiltros").hidden = !sim; $("abreFiltros").setAttribute("aria-expanded", String(sim)); if (sim) sincronizarPainel(); }
document.addEventListener("change", (ev) => { if (ev.target.matches("[data-foto]")) { const u = ev.target.dataset.foto; if (ev.target.checked) baixarFoto(u).then(() => marcarFoto(u, "ok"), () => {}); contarFotos(); } });
document.addEventListener("click", (ev) => {
  const t = ev.target;
  const vf = t.closest("[data-ver-foto]"); if (vf) { ev.preventDefault(); verFoto(vf.dataset.verFoto); return; }
  const tf = t.closest("[data-fotos]"); if (tf) {
    const todas = tf.dataset.fotos === "todas";
    [...document.querySelectorAll("#eFotos [data-foto]")].forEach((i, k) => { i.disabled = false; i.checked = todas && k < 10; const u = i.dataset.foto; if (i.checked) baixarFoto(u).then(() => marcarFoto(u, "ok"), () => {}); });
    contarFotos(); return;
  }
  if (t.closest("[data-reabrir-emp]") && atual) { delete detalheEmp[atual.it.id]; abrirEmp(atual.it.id); }
});
