// Roda dentro do WhatsApp Web. Recebe do painel: "contato" (nome da conversa aberta) e "colocar" (vídeo + legenda na conversa aberta).
// Nunca aperta Enviar: o corretor confere e envia.

const espera = (ms) => new Promise((r) => setTimeout(r, ms));
const visivel = (el) => !!el && el.getClientRects().length > 0;

function nomeDaConversa() {
  const h = document.querySelector("#main header");
  if (!h) return "";
  const el = h.querySelector("span[dir='auto'][title]") || h.querySelector("span[dir='auto']");
  return (el && (el.getAttribute("title") || el.textContent) || "").trim();
}

function caixaDeTexto() {
  return document.querySelector("#main footer div[contenteditable='true']");
}

// a caixa de legenda aparece na tela de prévia do anexo (fora do rodapé da conversa)
function caixaDeLegenda() {
  const todas = [...document.querySelectorAll("div[contenteditable='true']")].filter(visivel);
  const fora = todas.filter((el) => !el.closest("#main footer") && !el.closest("#side"));
  return fora[fora.length - 1] || null;
}

async function esperar(fn, ms) {
  const fim = Date.now() + ms;
  while (Date.now() < fim) { const r = fn(); if (r) return r; await espera(150); }
  return null;
}

function escrever(el, texto) {
  el.focus();
  const sel = window.getSelection(); sel.selectAllChildren(el); sel.collapseToEnd();
  // o editor do WhatsApp aceita texto inserido como se fosse digitado; quebra de linha vira Shift+Enter
  const linhas = texto.split("\n");
  linhas.forEach((l, i) => {
    if (i) document.execCommand("insertLineBreak");
    if (l) document.execCommand("insertText", false, l);
  });
  return (el.innerText || "").replace(/\s+/g, " ").includes(texto.split("\n")[0].replace(/\s+/g, " ").slice(0, 20));
}

async function anexarPorColar(arquivo) {
  const caixa = caixaDeTexto(); if (!caixa) return false;
  caixa.focus();
  const dt = new DataTransfer(); dt.items.add(arquivo);
  caixa.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
  return !!(await esperar(caixaDeLegenda, 6000));
}

async function anexarPeloClipe(arquivo) {
  const botao = document.querySelector("#main footer [data-icon='plus-rounded'], #main footer [data-icon='plus'], #main footer [data-icon='attach-menu-plus'], #main footer [data-icon='clip'], #main footer button[title*='Anexar'], #main footer div[title*='Anexar'], #main footer [aria-label*='Anexar'], #main footer [aria-label*='Attach']");
  if (botao) { (botao.closest("button,[role='button'],div[title]") || botao).click(); await espera(500); }
  const entrada = [...document.querySelectorAll("input[type='file']")].find((i) => /video|\*/.test(i.accept || "")) || document.querySelector("input[type='file']");
  if (!entrada) return false;
  const dt = new DataTransfer(); dt.items.add(arquivo);
  entrada.files = dt.files;
  entrada.dispatchEvent(new Event("change", { bubbles: true }));
  return !!(await esperar(caixaDeLegenda, 8000));
}

async function colocar({ url, nomeArquivo, texto }) {
  if (!document.querySelector("#main")) return { ok: false, erro: "Abra a conversa do cliente no WhatsApp primeiro." };
  let blob;
  try {
    const r = await fetch(url); if (!r.ok) throw new Error("HTTP " + r.status);
    blob = await r.blob();
  } catch (e) { return { ok: false, erro: "Não consegui baixar o vídeo (" + e.message + "). Confira a internet." }; }
  const arquivo = new File([blob], nomeArquivo, { type: "video/mp4" });
  let anexou = await anexarPorColar(arquivo);
  if (!anexou) anexou = await anexarPeloClipe(arquivo);
  if (!anexou) return { ok: false, erro: "O WhatsApp não abriu a prévia do vídeo. A mensagem está copiada: anexe o vídeo pelo clipe e cole." };
  await espera(300);
  const leg = caixaDeLegenda();
  const escreveu = leg ? escrever(leg, texto) : false;
  return { ok: true, legenda: escreveu };
}

chrome.runtime.onMessage.addListener((msg, _de, responder) => {
  if (msg && msg.acao === "contato") { responder({ nome: nomeDaConversa(), aberta: !!document.querySelector("#main") }); return; }
  if (msg && msg.acao === "colocar") { colocar(msg).then(responder, (e) => responder({ ok: false, erro: String(e && e.message || e) })); return true; }
});
