// Painel lateral: catálogo de follow-up ao lado do WhatsApp Web.
const BASE = "https://newlifeimoveissc-creator.github.io/newlife-followup/";
const CATS = [
  {k:"familia", t:"Família e segurança"}, {k:"valorizacao", t:"Valorização"}, {k:"gestao", t:"Região bem gerida"},
  {k:"exterior", t:"Quem mora fora"}, {k:"aluguel", t:"Turismo e aluguel"}, {k:"lazer", t:"Lazer"},
  {k:"educacao", t:"Educação e saúde"}, {k:"cultura", t:"História"}, {k:"bolha", t:"É bolha?"}, {k:"frio", t:"Lead frio"}
];
const CAT_T = Object.fromEntries(CATS.map((c) => [c.k, c.t]));
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const norm = (s) => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
let VIDEOS = [], filtro = "todos", atual = null, nomeManual = false;

function toast(t, ms){ const el = $("toast"); el.textContent = t; el.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => el.hidden = true, ms || 3000); }

// ---------- dados: sempre a versão mais nova do app; sem internet, a última guardada
async function carregar(){
  try {
    const r = await fetch(BASE + "dados.json", {cache: "no-cache"});
    const d = await r.json(); VIDEOS = d.videos;
    chrome.storage.local.set({dados: d});
  } catch (_) {
    const {dados} = await chrome.storage.local.get("dados");
    if (dados) { VIDEOS = dados.videos; toast("Sem internet: usando a última lista guardada."); }
  }
  renderFiltros(); renderLista();
}

// ---------- WhatsApp
async function abaZap(){
  const [ativa] = await chrome.tabs.query({active: true, lastFocusedWindow: true, url: "https://web.whatsapp.com/*"});
  if (ativa) return ativa;
  const todas = await chrome.tabs.query({url: "https://web.whatsapp.com/*"});
  return todas[0] || null;
}
async function falarComZap(msg){
  const aba = await abaZap();
  if (!aba) return {erro: "sem-aba"};
  try { return await chrome.tabs.sendMessage(aba.id, msg); }
  catch (_) { return {erro: "recarregar"}; }
}
async function atualizarConexao(){
  const r = await falarComZap({acao: "contato"});
  const st = $("conexao");
  if (r.erro === "sem-aba") { st.textContent = "abra o WhatsApp Web"; st.className = "status"; return; }
  if (r.erro === "recarregar") { st.textContent = "recarregue a aba do WhatsApp (F5)"; st.className = "status"; return; }
  st.className = "status ok";
  st.textContent = r.aberta ? "✓ conversa: " + (r.nome || "aberta") : "✓ WhatsApp conectado";
  if (!nomeManual && r.nome) {
    const primeiro = r.nome.replace(/[^\p{L}\s'-]/gu, " ").trim().split(/\s+/)[0] || "";
    if (primeiro && !/^\+?\d/.test(r.nome) && primeiro !== $("nome").value) { $("nome").value = primeiro; if (atual) renderMsgs(); }
  }
}
$("pegarNome").onclick = () => { nomeManual = false; atualizarConexao(); };
$("nome").addEventListener("input", () => { nomeManual = true; if (atual) renderMsgs(); });
setInterval(atualizarConexao, 2500);

// ---------- lista
function renderFiltros(){
  const n = (k) => k === "todos" ? VIDEOS.length : VIDEOS.filter((v) => v.cats.includes(k)).length;
  $("filtros").innerHTML = [{k:"todos", t:"Todos"}, ...CATS].map((f) => `<button class="f" type="button" data-f="${f.k}" aria-pressed="${f.k===filtro}">${esc(f.t)} ${n(f.k)}</button>`).join("");
}
function renderLista(){
  const q = norm($("busca").value.trim());
  const vs = VIDEOS.filter((v) => (filtro === "todos" || v.cats.includes(filtro)) && (!q || norm([v.titulo, v.resumo, v.dados.join(" "), v.objecoes.join(" ")].join(" ")).includes(q)));
  $("lista").innerHTML = vs.length ? vs.map((v) => `<button class="item" type="button" data-abrir="${v.slug}">
      <img src="${BASE}capas/${v.slug}.jpg" alt="" loading="lazy"><span><b>${esc(v.titulo)}</b><small>${esc(v.dur)} · ${esc(v.cats.slice(0,2).map((c) => CAT_T[c]).join(" · "))}</small></span></button>`).join("")
    : `<p class="vazio">${VIDEOS.length ? "Nada com esse filtro." : "Carregando…"}</p>`;
}
$("busca").addEventListener("input", renderLista);

// ---------- ficha
function preencher(t){
  const n = $("nome").value.trim();
  if (n) return t.replaceAll("{nome}", n);
  return t.replace(/(Oi|Olá|E aí|Bom dia|Boa tarde|Boa noite|Fala),? \{nome\}/g, "$1").replace(/^\{nome\},\s*(\S)/, (m, c) => c.toUpperCase()).replace(/,? \{nome\}/g, "").replaceAll("{nome}", "");
}
function renderMsgs(){
  const v = atual;
  $("fMsgs").innerHTML = v.msgs.map((m,i) => `<div class="msg${m.pol ? " pol" : ""}"><div class="rot">${esc(m.rot)}${m.pol ? " · só com cliente de direita" : ""}</div>
    <textarea id="m${i}" rows="4">${esc(preencher(m.t))}</textarea>
    <div class="acoes"><button class="btn zap" type="button" data-colocar="m${i}">Colocar na conversa</button><button class="btn sec min" type="button" data-copiar="m${i}">Copiar</button></div></div>`).join("");
  $("fAudios").innerHTML = v.audios.map((m,i) => `<div class="msg"><div class="rot">${esc(m.rot)}</div><textarea id="a${i}" rows="5">${esc(preencher(m.t))}</textarea></div>`).join("");
}
function abrir(slug){
  atual = VIDEOS.find((v) => v.slug === slug); if (!atual) return;
  const v = atual;
  $("player").poster = BASE + "capas/" + v.slug + ".jpg"; $("player").src = BASE + "videos/" + v.slug + ".mp4";
  $("fTitulo").textContent = v.titulo; $("fResumo").textContent = v.resumo;
  $("fDados").innerHTML = v.dados.map((d) => `<span class="dado">${esc(d)}</span>`).join("");
  $("fAviso").innerHTML = v.aviso ? `<div class="aviso">${esc(v.aviso)}</div>` : "";
  renderMsgs();
  $("lista").hidden = true; $("busca").hidden = true; $("filtros").hidden = true; $("ficha").hidden = false; window.scrollTo(0, 0);
}
function voltar(){ $("player").pause(); $("ficha").hidden = true; $("lista").hidden = false; $("busca").hidden = false; $("filtros").hidden = false; atual = null; }
$("voltar").onclick = voltar;

async function copiar(texto){ try { await navigator.clipboard.writeText(texto); return true; } catch(_) { return false; } }
async function colocar(botao, texto){
  const v = atual;
  botao.disabled = true; const antes = botao.textContent; botao.textContent = "Colocando…";
  copiar(texto);
  const r = await falarComZap({acao: "colocar", url: BASE + "videos/" + v.slug + ".mp4", nomeArquivo: v.titulo.replace(/[\\/:*?"<>|]/g, "-") + ".mp4", texto});
  botao.disabled = false; botao.textContent = antes;
  if (r.erro === "sem-aba") return toast("Abra o WhatsApp Web (web.whatsapp.com) e a conversa do cliente.", 4500);
  if (r.erro === "recarregar") return toast("Recarregue a aba do WhatsApp (F5) uma vez e tente de novo.", 4500);
  if (!r.ok) return toast(r.erro || "Não deu certo. A mensagem está copiada.", 5000);
  toast(r.legenda ? "Pronto: vídeo e legenda na conversa. Confira e aperte Enter." : "Vídeo na conversa. Clique na legenda e cole (⌘V): a mensagem está copiada.", 5000);
}
document.addEventListener("click", (ev) => {
  const t = ev.target;
  const f = t.closest("[data-f]"); if (f) { filtro = f.dataset.f; renderFiltros(); renderLista(); return; }
  const a = t.closest("[data-abrir]"); if (a) { abrir(a.dataset.abrir); return; }
  const c = t.closest("[data-copiar]"); if (c) { copiar($(c.dataset.copiar).value).then((ok) => toast(ok ? "Copiado" : "Não consegui copiar")); return; }
  const z = t.closest("[data-colocar]"); if (z) { colocar(z, $(z.dataset.colocar).value); return; }
});

carregar(); atualizarConexao();
