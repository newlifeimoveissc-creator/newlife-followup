// Lê o que o CLIENTE escreveu na conversa aberta e transforma em sinais (preço, família, mora fora…).
// Sem IA e sem internet: palavras-chave sobre o texto sem acento. Nada sai do computador do corretor.
const SINAIS = [
  {id: "caro", rot: "falou de preço", cats: ["valorizacao", "bolha"],
   re: /(\bcaro\b|\b(muito|ta|esta|achei|bem|meio) cara\b|salgad|\bprecos?\b|valor alto|ta alto|puxad|orcamento|desconto|negocia)/},
  {id: "bolha", rot: "medo de bolha", cats: ["bolha", "valorizacao"],
   re: /(bolha|desvaloriz|vai cair|cair o preco|vale a pena|compensa|baixar o preco)/},
  {id: "invest", rot: "pensa em investir", cats: ["valorizacao", "aluguel", "gestao"],
   re: /(investi|investment|retorno|rentab|valoriza|patrimonio|\brenda\b|aplicar)/},
  {id: "familia", rot: "família e segurança", cats: ["familia", "educacao"],
   re: /(seguranca|\bsegur[oa]\b|violen|assalt|\bfilh|crianca|familia|esposa|marido|\bnet[oa]s?\b|escola|tranquil|aposent|meus pais)/},
  {id: "aluguel", rot: "quer alugar", cats: ["aluguel", "lazer"],
   re: /(\balug|temporada|airbnb|booking|locacao|deixar alugado)/},
  {id: "exterior", rot: "mora fora", cats: ["exterior", "gestao"],
   re: /(\beua\b|estados unidos|\busa\b|boston|florida|miami|orlando|new jersey|nova york|massachusetts|connecticut|portugal|lisboa|\bporto\b(?! belo)|europa|londres|inglaterra|irlanda|italia|espanha|canada|japao|australia|dolar|\beuros?\b|exterior|voltar pro brasil|voltar para o brasil|morar fora)/},
  {id: "lazer", rot: "praia e lazer", cats: ["lazer", "aluguel"],
   re: /(\bpraia|verao|ferias|restaurante|\bnatal\b|reveillon|passeio|lazer|\bmar\b|vista)/},
  {id: "estrutura", rot: "estrutura e saúde", cats: ["gestao", "educacao"],
   re: /(hospital|\bsaude|medic|estrutura|saneamento|esgoto|transito|\bobras?\b|aeroporto)/},
  {id: "tempo", rot: "pediu tempo", cats: ["frio"],
   re: /(vou pensar|pensar com calma|mais pra frente|mais para frente|ano que vem|depois eu vejo|nao e o momento|sem pressa|vou ver|te aviso|te falo|qualquer coisa te|agora nao)/},
];
const norm = (s) => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();

// conversa = [{de: "cliente"|"eu"|"?", t, quando}] → {sinais: [{id, rot, cats, trecho}], parada: dias | 0}
function lerConversa(conversa) {
  if (!conversa || !conversa.length) return {sinais: [], parada: 0};
  const doCliente = conversa.filter((m) => m.de === "cliente");
  const base = doCliente.length ? doCliente : conversa.filter((m) => m.de !== "eu");
  const achados = new Map();
  base.forEach((m, i) => {
    const t = norm(m.t);
    SINAIS.forEach((s) => {
      const r = t.match(s.re);
      if (r) achados.set(s.id, {...s, trecho: recorte(m.t, r.index), peso: 1 + i / base.length});
    });
  });
  const ultima = conversa[conversa.length - 1];
  const ultimaCliente = doCliente[doCliente.length - 1];
  const agora = Date.now(), dia = 864e5;
  let parada = 0;
  if (ultima && ultima.quando) {
    const dias = Math.floor((agora - ultima.quando) / dia);
    const semResposta = ultima.de === "eu" && dias >= 3;
    const quieto = ultimaCliente && ultimaCliente.quando && (agora - ultimaCliente.quando) / dia >= 5;
    if (semResposta || quieto) parada = Math.max(dias, ultimaCliente && ultimaCliente.quando ? Math.floor((agora - ultimaCliente.quando) / dia) : dias);
  }
  return {sinais: [...achados.values()].sort((a, b) => b.peso - a.peso), parada};
}

function recorte(texto, pos) {
  // o trecho da frase do cliente onde a palavra apareceu (a posição vem do texto sem acento, que tem o mesmo tamanho)
  const ini = Math.max(0, pos - 30), fim = Math.min(texto.length, pos + 40);
  return (ini ? "…" : "") + texto.slice(ini, fim).trim() + (fim < texto.length ? "…" : "");
}

// pontua um vídeo ou notícia pelos sinais: categoria principal vale mais
function pontuar(item, sinais, parada) {
  let p = 0;
  const cats = item.cats || [];
  sinais.forEach((s) => s.cats.forEach((c, j) => { const k = cats.indexOf(c); if (k >= 0) p += [3, 1.2, 0.5][Math.min(k, 2)] * (j ? 0.6 : 1) * s.peso; }));
  if (p && parada && cats.includes("frio")) p += 0.3;
  return p;
}

// escolhe n itens alternando os assuntos do cliente: o melhor de cada assunto, na ordem em que pesam
function escolher(lista, sinais, parada, n, jaFoi){
  const cand = lista.filter((x) => !jaFoi(x));
  const filas = sinais.map((s) => cand.map((x) => ({x, p: pontuar(x, [s], parada)})).filter((o) => o.p > 0).sort((a, b) => b.p - a.p));
  const usados = new Set(), out = [];
  while (out.length < n && filas.some((f) => f.length)) {
    filas.forEach((f, i) => {
      if (out.length >= n) return;
      while (f.length && usados.has(f[0].x.slug)) f.shift();
      const o = f.shift(); if (o) { usados.add(o.x.slug); out.push({x: o.x, por: sinais[i].rot}); }
    });
  }
  if (!out.length && parada) cand.filter((x) => (x.cats || []).includes("frio")).slice(0, n).forEach((x) => out.push({x, por: "conversa parada"}));
  return out;
}
