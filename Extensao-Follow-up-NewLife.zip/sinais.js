// Análise da conversa: lê o que o CLIENTE escreveu na conversa aberta e separa por ASSUNTO
// (praia, valorização, segurança…), marcando quando ele PERGUNTOU. Cada assunto puxa a notícia e os vídeos
// que falam daquilo: pela categoria e pela própria palavra (quem perguntou de praia recebe o vídeo das praias).
// Sem IA e sem internet: nada da conversa sai do computador do corretor.
const ASSUNTOS = [
  {id: "praia", rot: "Praia e mar", cats: ["lazer", "aluguel", "valorizacao"],
   re: /(\bpraias?\b|\bmar\b|\borla\b|\bareia\b|beira[ -]?mar|frente[ -]?(pro |para o )?mar|pe na areia|vista (pro|para o|do) mar|banho de mar|meia praia|praia brava)/,
   termos: ["praia", "mar ", "orla", "areia", "frente-mar", "frente mar", "beira-mar", "guarda-vidas"]},
  {id: "valorizacao", rot: "Valorização", cats: ["valorizacao", "bolha", "gestao"],
   re: /(valoriz|vai subir|vai valer|subir o preco|ganhar dinheiro|\blucro|retorno|rentab|investi|investment|patrimonio|\baplicar\b|bom negocio)/,
   termos: ["valoriz", "m²", "metro quadrado", "fipezap", "investi", "alargamento", "procura"]},
  {id: "bolha", rot: "Medo de bolha", cats: ["bolha", "valorizacao", "gestao"],
   re: /(bolha|desvaloriz|vai cair|cair o preco|baixar o preco|vale a pena|compensa|nao sei se|tenho medo|e arriscado|arrisc)/,
   termos: ["bolha", "cresc", "populac", "moradores", "procura", "pib"]},
  {id: "preco", rot: "Achou caro", cats: ["valorizacao", "bolha"],
   re: /(\bcaro\b|\b(muito|ta|esta|achei|bem|meio) cara\b|salgad|\bprecos?\b|valor alto|ta alto|puxad|orcamento|desconto|negocia|condicao de pagamento|parcel|entrada)/,
   termos: ["m²", "valoriz", "fipezap", "metro quadrado"]},
  {id: "seguranca", rot: "Segurança", cats: ["familia", "gestao"],
   re: /(seguranca|\bsegur[oa]s?\b|violen|assalt|roubo|\bcrime|perigos|policia|tranquil|sossego)/,
   termos: ["segur", "violen", "policia", "mortes", "guarda-vidas", "tranquil"]},
  {id: "familia", rot: "Família e filhos", cats: ["familia", "educacao", "lazer"],
   re: /(\bfilh|crianca|familia|esposa|marido|\bnet[oa]s?\b|escola|colegio|aposent|meus pais|\bbebe\b|qualidade de vida)/,
   termos: ["famil", "escola", "crianc", "filhos", "alfabetiz", "qualidade de vida"]},
  {id: "aluguel", rot: "Alugar e temporada", cats: ["aluguel", "lazer", "valorizacao"],
   re: /(\balug|temporada|airbnb|booking|locacao|deixar alugado|renda extra)/,
   termos: ["alug", "temporada", "turista", "reveillon", "ocupac", "hospedag"]},
  {id: "exterior", rot: "Mora fora e dólar", cats: ["exterior", "gestao"],
   re: /(\beua\b|estados unidos|\busa\b|boston|florida|miami|orlando|new jersey|nova york|massachusetts|connecticut|portugal|lisboa|europa|londres|inglaterra|irlanda|italia|espanha|canada|japao|australia|dolar|\beuros?\b|exterior|voltar pro brasil|voltar para o brasil|morar fora|moro fora)/,
   termos: ["dolar", "exterior", "florida", "eua", "estados unidos", "voltando", "fora do brasil"]},
  {id: "lazer", rot: "Lazer e eventos", cats: ["lazer", "aluguel"],
   re: /(verao|ferias|restaurante|\bnatal\b|reveillon|passeio|lazer|evento|\bshow|parque|beto carrero|gastronom|vida noturna)/,
   termos: ["natal", "reveillon", "verao", "parque", "evento", "show", "gastronom"]},
  {id: "estrutura", rot: "Estrutura e saúde", cats: ["gestao", "educacao"],
   re: /(hospital|\bsaude|medic|estrutura|saneamento|esgoto|transito|\bobras?\b|aeroporto|estrada|br[ -]?101|mobilidade|shopping|mercado)/,
   termos: ["hospital", "saude", "obra", "aeroporto", "tunel", "esgoto", "br-101", "passarela", "shopping"]},
  {id: "economia", rot: "Economia e gestão", cats: ["gestao", "valorizacao"],
   re: /(economia|emprego|desemprego|governo|prefeitura|gestao|imposto|politic|\bpt\b|\blula\b|bolsonaro|direita|esquerda)/,
   termos: ["pib", "econom", "emprego", "governo", "gestao", "estado"]},
  {id: "tempo", rot: "Pediu tempo", cats: ["frio"],
   re: /(vou pensar|pensar com calma|mais pra frente|mais para frente|ano que vem|depois eu vejo|nao e o momento|sem pressa|vou ver|te aviso|te falo|qualquer coisa te|agora nao|mais tarde)/,
   termos: []},
];
const norm = (s) => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
const PERGUNTA = /\?|^\s*(sera|como|qual|quais|quanto|quantos|quando|onde|porque|por que|vale|tem\b|da pra|e a\b|e o\b|e verdade|voce acha|sabe se)/;
const POLITICA = /(politic|\bpt\b|\blula\b|bolsonaro|direita|esquerda)/;

// conversa = [{de: "cliente"|"eu"|"?", t, quando}]
// → {assuntos: [{id, rot, cats, termos, trecho, perguntou, vezes, peso}], parada: dias | 0, lidas, ultimaCliente, politica}
function lerConversa(conversa) {
  const vazio = {assuntos: [], parada: 0, lidas: 0, ultimaCliente: 0, politica: false};
  if (!conversa || !conversa.length) return vazio;
  const doCliente = conversa.filter((m) => m.de === "cliente");
  const base = doCliente.length ? doCliente : conversa.filter((m) => m.de !== "eu");
  const achados = new Map();
  let politica = false;
  base.forEach((m, i) => {
    const t = norm(m.t);
    if (POLITICA.test(t)) politica = true;
    ASSUNTOS.forEach((a) => {
      const r = t.match(a.re); if (!r) return;
      const fr = frase(m.t, t, r.index), perg = PERGUNTA.test(norm(fr));
      const ant = achados.get(a.id);
      const recencia = 1 + i / Math.max(1, base.length);
      const peso = recencia + (perg ? 1.5 : 0) + (ant ? 0.5 * ant.vezes : 0);
      // a frase que vale mostrar é a pergunta (se houver) ou a mais recente
      const trocar = !ant || perg || !ant.perguntou;
      achados.set(a.id, {...a,
        trecho: trocar ? fr : ant.trecho,
        perguntou: (ant && ant.perguntou) || perg,
        vezes: (ant ? ant.vezes : 0) + 1,
        peso: Math.max(peso, ant ? ant.peso : 0)});
    });
  });
  const ultima = conversa[conversa.length - 1];
  const uc = doCliente[doCliente.length - 1];
  const agora = Date.now(), dia = 864e5;
  let parada = 0;
  if (ultima && ultima.quando) {
    const dias = Math.floor((agora - ultima.quando) / dia);
    const diasCliente = uc && uc.quando ? Math.floor((agora - uc.quando) / dia) : dias;
    if ((ultima.de === "eu" && dias >= 3) || diasCliente >= 5) parada = Math.max(dias, diasCliente);
  }
  const assuntos = [...achados.values()].sort((a, b) => b.peso - a.peso);
  return {assuntos, parada, lidas: base.length, ultimaCliente: uc && uc.quando || 0, politica};
}

// a frase do cliente onde a palavra apareceu, com a pontuação dela (é a frase que diz se ele PERGUNTOU)
// (a posição vem do texto sem acento, que tem o mesmo tamanho do original)
function frase(texto, t, pos) {
  let ini = pos; while (ini > 0 && !/[.!?\n]/.test(t[ini - 1])) ini--;
  let fim = pos; while (fim < t.length && !/[.!?\n]/.test(t[fim])) fim++;
  if (fim < t.length && /[?!]/.test(t[fim])) fim++;
  let f = texto.slice(ini, fim).trim();
  if (f.length > 120) { const c = Math.max(0, pos - ini - 50); f = (c ? "…" : "") + f.slice(c, c + 110).trim() + "…"; }
  return f;
}

// quanto um vídeo ou notícia responde a UM assunto: a palavra do assunto no título/resumo pesa mais que a categoria
function pontuar(item, assunto, parada) {
  const cats = item.cats || [];
  let p = 0;
  assunto.cats.forEach((c, j) => { const k = cats.indexOf(c); if (k >= 0) p += [3, 1.2, 0.5][Math.min(k, 2)] * (j ? 0.6 : 1); });
  const texto = " " + norm([item.titulo, item.resumo, (item.dados || []).join(" ")].join(" ")) + " ";
  const bateu = assunto.termos.filter((t) => texto.includes(norm(t))).length;
  if (bateu) p += 3 + bateu;
  if (p && parada && cats.includes("frio")) p += 0.3;
  return p * assunto.peso;
}

// os melhores de um assunto, sem repetir o que já foi sugerido em outro assunto nem o que o cliente já recebeu
function melhores(lista, assunto, parada, n, jaFoi, usados) {
  return lista.filter((x) => !jaFoi(x) && !usados.has(x.slug))
    .map((x) => ({x, p: pontuar(x, assunto, parada)})).filter((o) => o.p > 0)
    .sort((a, b) => b.p - a.p).slice(0, n).map((o) => { usados.add(o.x.slug); return o.x; });
}
