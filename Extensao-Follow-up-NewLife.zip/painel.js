// Painel lateral: catálogo de follow-up ao lado do WhatsApp Web.
// Vídeos + notícias confiáveis, histórico do que cada cliente já recebeu e sugestão pela conversa aberta.
const BASE = "https://newlifeimoveissc-creator.github.io/newlife-followup/";
const CATS = [
  {k:"familia", t:"Família e segurança"}, {k:"valorizacao", t:"Valorização"}, {k:"gestao", t:"Região bem gerida"},
  {k:"exterior", t:"Quem mora fora"}, {k:"aluguel", t:"Turismo e aluguel"}, {k:"lazer", t:"Lazer"},
  {k:"educacao", t:"Educação e saúde"}, {k:"cultura", t:"História"}, {k:"bolha", t:"É bolha?"}, {k:"frio", t:"Lead frio"}
];
const CAT_T = Object.fromEntries(CATS.map((c) => [c.k, c.t]));
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
let VIDEOS = [], NOTICIAS = [], aba = "videos", filtro = "todos", atual = null, nomeManual = false;
let contato = {chave: "", nome: "", conversa: []}, HIST = {}, assinaturaConversa = "", sugestaoFechada = {};

function toast(t, ms){ const el = $("toast"); el.textContent = t; el.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => el.hidden = true, ms || 3000); }
const hoje = () => new Date().toISOString().slice(0, 10);
const dataCurta = (ts) => { const d = new Date(ts); return String(d.getDate()).padStart(2, "0") + "/" + String(d.getMonth() + 1).padStart(2, "0"); };
function quandoFoi(iso){
  const d = Math.round((new Date(hoje()) - new Date(iso)) / 864e5);
  return d <= 0 ? "hoje" : d === 1 ? "ontem" : d < 7 ? `há ${d} dias` : iso.slice(8, 10) + "/" + iso.slice(5, 7);
}

// ---------- dados: sempre a versão mais nova do app; sem internet, a última guardada
async function baixar(arq){
  try {
    const r = await fetch(BASE + arq, {cache: "no-cache"}); if (!r.ok) throw 0;
    const d = await r.json(); chrome.storage.local.set({[arq]: d}); return d;
  } catch (_) { const g = await chrome.storage.local.get(arq); return g[arq] || null; }
}
async function carregar(){
  const [dv, dn, h] = await Promise.all([baixar("dados.json"), baixar("noticias.json"), chrome.storage.local.get("hist")]);
  if (!dv) toast("Sem internet e sem lista guardada. Conecte e reabra o painel.", 6000);
  VIDEOS = dv ? dv.videos : [];
  NOTICIAS = (dn ? dn.noticias : []).filter((n) => !n.validade || n.validade >= hoje()).sort((a, b) => b.data.localeCompare(a.data));
  HIST = h.hist || {};
  $("nV").textContent = VIDEOS.length; $("nN").textContent = NOTICIAS.length || "";
  renderFiltros(); renderLista(); renderHist(); renderSugestao();
}

// ---------- histórico por cliente (fica no computador, chrome.storage)
const chaveDe = (nome) => norm(nome).replace(/\s+/g, " ").trim();
const idItem = (tipo, slug) => tipo + ":" + slug;
function enviados(){ return (HIST[contato.chave] || {}).itens || {}; }
function jaRecebeu(tipo, slug){ return enviados()[idItem(tipo, slug)] || 0; }
function registrar(tipo, slug){
  if (!contato.chave) return;
  const h = HIST[contato.chave] || (HIST[contato.chave] = {nome: contato.nome, itens: {}});
  h.nome = contato.nome || h.nome; h.itens[idItem(tipo, slug)] = Date.now();
  chrome.storage.local.set({hist: HIST}); renderHist(); renderLista(); renderSugestao();
}
function desfazer(id){
  const h = HIST[contato.chave]; if (!h) return;
  delete h.itens[id]; chrome.storage.local.set({hist: HIST}); renderHist(); renderLista(); renderSugestao(); if (atual) mostrarJa();
}
function acharItem(id){
  const [tipo, slug] = id.split(":");
  const it = (tipo === "v" ? VIDEOS : NOTICIAS).find((x) => x.slug === slug);
  return it ? {tipo, it} : null;
}
function renderHist(){
  const el = $("hist"), lista = Object.entries(enviados()).sort((a, b) => b[1] - a[1]);
  if (!contato.chave || !lista.length) { el.hidden = !contato.chave; el.innerHTML = contato.chave ? `<span class="hist-vazio">${esc(contato.nome)} ainda não recebeu nada por aqui.</span>` : ""; return; }
  const nv = lista.filter(([id]) => id[0] === "v").length, nn = lista.length - nv;
  const partes = [nv && `${nv} vídeo${nv > 1 ? "s" : ""}`, nn && `${nn} notícia${nn > 1 ? "s" : ""}`].filter(Boolean).join(" e ");
  el.hidden = false;
  el.innerHTML = `<details><summary>${esc(contato.nome)} já recebeu ${partes} · último em ${dataCurta(lista[0][1])}</summary><ul>` +
    lista.map(([id, ts]) => { const a = acharItem(id); return `<li><button type="button" class="link" data-abrir-id="${esc(id)}">${esc(a ? a.it.titulo : id)}</button><small>${dataCurta(ts)}</small><button type="button" class="x" title="Não mandei: tirar da lista" data-desfazer="${esc(id)}">✕</button></li>`; }).join("") + `</ul></details>`;
}

// ---------- WhatsApp
async function abaZap(){
  const [ativa] = await chrome.tabs.query({active: true, lastFocusedWindow: true, url: "https://web.whatsapp.com/*"});
  if (ativa) return ativa;
  const todas = await chrome.tabs.query({url: "https://web.whatsapp.com/*"});
  return todas[0] || null;
}
async function falarComZap(msg){
  const aba = await abaZap();
  if (!aba) return {erro: "sem-aba"};
  try { return await chrome.tabs.sendMessage(aba.id, msg); }
  catch (_) { return {erro: "recarregar"}; }
}
const primeiroNome = (n) => { const p = n.replace(/[^\p{L}\s'-]/gu, " ").trim().split(/\s+/)[0] || ""; return /^\+?\d/.test(n) ? "" : p; };
async function atualizarConexao(){
  const r = await falarComZap({acao: "contato"});
  const st = $("conexao");
  if (r.erro === "sem-aba") { st.textContent = "abra o WhatsApp Web"; st.className = "status"; return; }
  if (r.erro === "recarregar") { st.textContent = "recarregue a aba do WhatsApp (F5)"; st.className = "status"; return; }
  st.className = "status ok";
  st.textContent = r.aberta ? "✓ conversa: " + (r.nome || "aberta") : "✓ WhatsApp conectado";
  if (nomeManual) return;
  const nome = r.aberta ? (r.nome || "") : "";
  const chave = nome ? chaveDe(nome) : "";
  const assinatura = (r.conversa || []).map((m) => m.de + m.quando + m.t.length).join("|");
  if (chave !== contato.chave) {
    contato = {chave, nome, conversa: r.conversa || []}; assinaturaConversa = assinatura;
    $("nome").value = nome ? primeiroNome(nome) : "";
    if (atual) { renderMsgsAtual(); mostrarJa(); }
    renderHist(); renderLista(); renderSugestao();
  } else if (assinatura !== assinaturaConversa) {
    contato.conversa = r.conversa || []; assinaturaConversa = assinatura; renderSugestao();
  }
}
$("pegarNome").onclick = () => { nomeManual = false; contato.chave = "~"; atualizarConexao(); };
$("nome").addEventListener("input", () => {
  nomeManual = true;
  const n = $("nome").value.trim();
  contato = {chave: n ? chaveDe(n) : "", nome: n, conversa: []};
  if (atual) { renderMsgsAtual(); mostrarJa(); }
  renderHist(); renderLista(); renderSugestao();
});
setInterval(atualizarConexao, 2500);

// ---------- sugestão pela conversa
function renderSugestao(){
  const el = $("sugestao");
  if (!contato.chave || sugestaoFechada[contato.chave] || !contato.conversa.length || atual) { el.hidden = true; return; }
  const {sinais, parada} = lerConversa(contato.conversa);
  if (!sinais.length && !parada) { el.hidden = true; return; }
  const vs = escolher(VIDEOS, sinais, parada, 3, (x) => jaRecebeu("v", x.slug));
  const ns = escolher(NOTICIAS, sinais, parada, 2, (x) => jaRecebeu("n", x.slug));
  const chips = sinais.slice(0, 4).map((s) => `<span class="sinal" title="${esc(s.trecho)}">${esc(s.rot)}</span>`).join("");
  const motivo = parada ? `<p class="parada">Conversa parada há ${parada} dia${parada > 1 ? "s" : ""}: mande algo leve, sem cobrar. As mensagens "Lead frio" já vêm marcadas.</p>` : "";
  const trecho = sinais[0] ? `<p class="trecho">“${esc(sinais[0].trecho)}”</p>` : "";
  const linha = (tipo, {x, por}) => tipo === "v"
    ? `<button class="item mini" type="button" data-abrir="${x.slug}" data-tipo="v"><img src="${BASE}capas/${x.slug}.jpg" alt="" loading="lazy"><span><b>${esc(x.titulo)}</b><small>Vídeo · por: ${esc(por)}</small></span></button>`
    : `<button class="item mini" type="button" data-abrir="${x.slug}" data-tipo="n">${selo(x, true)}<span><b>${esc(x.titulo)}</b><small>${esc(x.fonte.nome)} · ${quandoFoi(x.data)} · por: ${esc(por)}</small></span></button>`;
  const itens = [...vs.map((o) => linha("v", o)), ...ns.map((o) => linha("n", o))].join("");
  el.hidden = false;
  el.innerHTML = `<div class="sug-topo"><b>Pela conversa com ${esc(primeiroNome(contato.nome) || contato.nome)}</b><button type="button" class="x" data-fechar-sug title="Esconder">✕</button></div>
    <div class="sinais">${chips}</div>${trecho}${motivo}${itens || `<p class="dica">Ele já recebeu tudo o que combina. Veja as notícias novas.</p>`}
    <p class="privado">Lido só aqui no seu computador. Nada da conversa sai daqui.</p>`;
}

// ---------- lista
function renderFiltros(){
  const base = aba === "videos" ? VIDEOS : NOTICIAS;
  const n = (k) => k === "todos" ? base.length : base.filter((v) => v.cats.includes(k)).length;
  $("filtros").innerHTML = [{k:"todos", t:"Todos"}, ...CATS].filter((f) => n(f.k)).map((f) => `<button class="f" type="button" data-f="${f.k}" aria-pressed="${f.k===filtro}">${esc(f.t)} ${n(f.k)}</button>`).join("");
}
function selo(n, mini){
  const of = n.fonte.tipo === "oficial";
  return `<span class="selo ${of ? "oficial" : "imprensa"}${mini ? " mini" : ""}">${of ? "Oficial" : "Imprensa"}</span>`;
}
function marcaEnviado(tipo, slug){ const ts = jaRecebeu(tipo, slug); return ts ? `<em class="enviado">enviado ${dataCurta(ts)}</em>` : ""; }
function renderLista(){
  const q = norm($("busca").value.trim()), esconder = $("esconder").checked && contato.chave;
  const tipo = aba === "videos" ? "v" : "n", base = aba === "videos" ? VIDEOS : NOTICIAS;
  const texto = (v) => norm([v.titulo, v.resumo, (v.dados || []).join(" "), (v.objecoes || []).join(" "), v.fonte ? v.fonte.nome : ""].join(" "));
  const vs = base.filter((v) => (filtro === "todos" || v.cats.includes(filtro)) && (!q || texto(v).includes(q)) && !(esconder && jaRecebeu(tipo, v.slug)));
  const item = (v) => tipo === "v"
    ? `<button class="item" type="button" data-abrir="${v.slug}" data-tipo="v"><img src="${BASE}capas/${v.slug}.jpg" alt="" loading="lazy"><span><b>${esc(v.titulo)}</b><small>${esc(v.dur)} · ${esc(v.cats.slice(0,2).map((c) => CAT_T[c]).join(" · "))}</small>${marcaEnviado("v", v.slug)}</span></button>`
    : `<button class="item noticia" type="button" data-abrir="${v.slug}" data-tipo="n">${selo(v)}<span><b>${esc(v.titulo)}</b><small>${esc(v.fonte.nome)} · ${quandoFoi(v.data)}</small>${marcaEnviado("n", v.slug)}</span></button>`;
  const vazio = !base.length ? (aba === "noticias" ? "As notícias do dia aparecem aqui." : "Carregando…") : "Nada com esse filtro.";
  $("lista").innerHTML = vs.length ? vs.map(item).join("") : `<p class="vazio">${vazio}</p>`;
}
$("busca").addEventListener("input", renderLista);
$("esconder").addEventListener("change", renderLista);
function trocarAba(a){
  aba = a; filtro = "todos";
  document.querySelectorAll("[data-aba]").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.aba === a)));
  $("busca").placeholder = a === "videos" ? "Buscar: segurança, frente-mar, Natal…" : "Buscar: IBGE, dólar, segurança, aluguel…";
  renderFiltros(); renderLista();
}

// ---------- fichas
function preencher(t, link){
  const n = $("nome").value.trim();
  let s = n ? t.replaceAll("{nome}", n)
    : t.replace(/(Oi|Olá|E aí|Bom dia|Boa tarde|Boa noite|Fala),? \{nome\}/g, "$1").replace(/^\{nome\},\s*(\S)/, (m, c) => c.toUpperCase()).replace(/,? \{nome\}/g, "").replaceAll("{nome}", "");
  return link ? s.replaceAll("{link}", link) : s;
}
function blocoMsgs(msgs, link, destacarFrio){
  return msgs.map((m,i) => { const frio = destacarFrio && /frio/i.test(m.rot);
    return `<div class="msg${m.pol ? " pol" : ""}${frio ? " destaque" : ""}"><div class="rot">${esc(m.rot)}${m.pol ? " · só com cliente de direita" : ""}${frio ? " · sugerida pela conversa" : ""}</div>
    <textarea id="m${i}" rows="4">${esc(preencher(m.t, link))}</textarea>
    <div class="acoes"><button class="btn zap" type="button" data-colocar="m${i}">Colocar na conversa</button><button class="btn sec min" type="button" data-copiar="m${i}">Copiar</button></div></div>`; }).join("");
}
const blocoAudios = (a) => a.map((m,i) => `<div class="msg"><div class="rot">${esc(m.rot)}</div><textarea id="a${i}" rows="5">${esc(preencher(m.t))}</textarea></div>`).join("");
function paradaAgora(){ return contato.conversa.length ? lerConversa(contato.conversa).parada : 0; }
function renderMsgsAtual(){
  if (!atual) return;
  const v = atual.it, frio = paradaAgora() > 0;
  ["fMsgs", "fAudios", "nMsgs", "nAudios"].forEach((id) => $(id).innerHTML = "");
  if (atual.tipo === "v") { $("fMsgs").innerHTML = blocoMsgs(v.msgs, "", frio); $("fAudios").innerHTML = blocoAudios(v.audios); }
  else { $("nMsgs").innerHTML = blocoMsgs(v.msgs, v.fonte.url, frio); $("nAudios").innerHTML = blocoAudios(v.audios); }
}
function mostrarJa(){
  if (!atual) return;
  const ts = jaRecebeu(atual.tipo, atual.it.slug);
  const html = ts ? `<div class="ja">${esc(primeiroNome(contato.nome) || contato.nome)} já recebeu ${atual.tipo === "v" ? "esse vídeo" : "essa notícia"} em ${dataCurta(ts)}. <button type="button" class="link" data-desfazer="${idItem(atual.tipo, atual.it.slug)}">Não mandei</button></div>` : "";
  $(atual.tipo === "v" ? "fJa" : "nJa").innerHTML = html;
}
function abrir(tipo, slug){
  const it = (tipo === "v" ? VIDEOS : NOTICIAS).find((x) => x.slug === slug); if (!it) return;
  if (atual && atual.tipo === "v") $("player").pause();
  atual = {tipo, it};
  $("navegar").hidden = true; $("sugestao").hidden = true; $("ficha").hidden = tipo !== "v"; $("fichaN").hidden = tipo !== "n";
  if (tipo === "v") {
    $("player").poster = BASE + "capas/" + it.slug + ".jpg"; $("player").src = BASE + "videos/" + it.slug + ".mp4";
    $("fTitulo").textContent = it.titulo; $("fResumo").textContent = it.resumo;
    $("fDados").innerHTML = it.dados.map((d) => `<span class="dado">${esc(d)}</span>`).join("");
    $("fAviso").innerHTML = it.aviso ? `<div class="aviso">${esc(it.aviso)}</div>` : "";
  } else {
    $("nSelo").innerHTML = `<div class="fonte">${selo(it)}<b>${esc(it.fonte.nome)}</b><small>${quandoFoi(it.data)}${it.dado_de ? " · dado: " + esc(it.dado_de) : ""}</small></div>`;
    $("nTitulo").textContent = it.titulo; $("nResumo").textContent = it.resumo;
    $("nDados").innerHTML = it.dados.map((d) => `<span class="dado">${esc(d)}</span>`).join("");
    $("nConferido").textContent = it.conferido ? "✓ Conferido pela New Life: " + it.conferido : "";
    $("nAbrir").href = it.fonte.url;
    $("nAviso").innerHTML = it.aviso ? `<div class="aviso">${esc(it.aviso)}</div>` : "";
    const rel = (it.videos || []).map((s) => VIDEOS.find((v) => v.slug === s)).filter(Boolean);
    $("nVideos").innerHTML = rel.length ? `<h3>Vídeos que combinam</h3>` + rel.map((v) => `<button class="item mini" type="button" data-abrir="${v.slug}" data-tipo="v"><img src="${BASE}capas/${v.slug}.jpg" alt=""><span><b>${esc(v.titulo)}</b><small>${esc(v.dur)}</small></span></button>`).join("") : "";
  }
  renderMsgsAtual(); mostrarJa(); window.scrollTo(0, 0);
  const d = document.querySelector(".msg.destaque"); if (d) setTimeout(() => d.scrollIntoView({block: "center", behavior: "smooth"}), 250);
}
function voltar(){ $("player").pause(); $("ficha").hidden = true; $("fichaN").hidden = true; $("navegar").hidden = false; atual = null; renderSugestao(); }

async function copiar(texto){ try { await navigator.clipboard.writeText(texto); return true; } catch(_) { return false; } }
async function colocar(botao, texto){
  const {tipo, it} = atual;
  botao.disabled = true; const antes = botao.textContent; botao.textContent = "Colocando…";
  copiar(texto);
  const r = tipo === "v"
    ? await falarComZap({acao: "colocar", url: BASE + "videos/" + it.slug + ".mp4", nomeArquivo: it.titulo.replace(/[\\/:*?"<>|]/g, "-") + ".mp4", texto})
    : await falarComZap({acao: "texto", texto});
  botao.disabled = false; botao.textContent = antes;
  if (r.erro === "sem-aba") return toast("Abra o WhatsApp Web (web.whatsapp.com) e a conversa do cliente.", 4500);
  if (r.erro === "recarregar") return toast("Recarregue a aba do WhatsApp (F5) uma vez e tente de novo.", 4500);
  if (!r.ok) return toast(r.erro || "Não deu certo. A mensagem está copiada.", 5000);
  registrar(tipo, it.slug); mostrarJa();
  if (tipo === "n") return toast(r.escreveu ? "Pronto: mensagem e link na conversa. Espere a prévia aparecer e aperte Enter." : "A mensagem está copiada: clique na conversa e cole (⌘V).", 5000);
  toast(r.legenda ? "Pronto: vídeo e legenda na conversa. Confira e aperte Enter." : "Vídeo na conversa. Clique na legenda e cole (⌘V): a mensagem está copiada.", 5000);
}
document.addEventListener("click", (ev) => {
  const t = ev.target;
  const ab = t.closest("[data-aba]"); if (ab) { trocarAba(ab.dataset.aba); return; }
  const f = t.closest("[data-f]"); if (f) { filtro = f.dataset.f; renderFiltros(); renderLista(); return; }
  const a = t.closest("[data-abrir]"); if (a) { abrir(a.dataset.tipo || "v", a.dataset.abrir); return; }
  const ai = t.closest("[data-abrir-id]"); if (ai) { const [tp, sl] = ai.dataset.abrirId.split(":"); abrir(tp, sl); return; }
  const dz = t.closest("[data-desfazer]"); if (dz) { ev.preventDefault(); desfazer(dz.dataset.desfazer); return; }
  const fs = t.closest("[data-fechar-sug]"); if (fs) { sugestaoFechada[contato.chave] = true; renderSugestao(); return; }
  if (t.closest("[data-voltar]")) { voltar(); return; }
  if (t.closest("[data-marcar]")) { if (!contato.chave) return toast("Escreva o nome do cliente (ou abra a conversa) para guardar no histórico.", 4000); registrar(atual.tipo, atual.it.slug); mostrarJa(); toast("Guardado no histórico de " + (primeiroNome(contato.nome) || contato.nome)); return; }
  const c = t.closest("[data-copiar]"); if (c) { copiar($(c.dataset.copiar).value).then((ok) => toast(ok ? "Copiado" : "Não consegui copiar")); return; }
  const z = t.closest("[data-colocar]"); if (z) { colocar(z, $(z.dataset.colocar).value); return; }
});

carregar(); atualizarConexao();
