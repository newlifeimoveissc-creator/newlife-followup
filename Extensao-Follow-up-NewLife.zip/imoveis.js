// Empreendimentos do DWV e do Top 3, puxados com o login do PRÓPRIO corretor neste Chrome.
// Nada é publicado em lugar nenhum: a lista fica guardada só no computador dele (chrome.storage) e atualiza sozinha.
//
// DWV: o mapa interno (/api/internal/map) devolve 1 linha por empreendimento (preço inicial, quartos, área,
//      entrega, foto). Precisa do login. O link pro cliente é o "Hotsite com minha assinatura e contato"
//      (createTrackedLink): abre sem login, mostra o nome e o contato do corretor e o DWV conta as visitas.
// Top 3: lista e ficha curta são públicas (/wp-json/extds/v1/...). A descrição completa e a forma de pagamento
//      ficam na página do imóvel, que pede login. O link do Top 3 cai no login pro cliente, então pro cliente
//      vão as FOTOS + o texto (nunca o link, nunca o nome do agenciador).

const FONTES = {
  dwv:  {nome: "DWV",   origem: "https://app.dwvapp.com.br",        casa: "https://app.dwvapp.com.br/home"},
  top3: {nome: "Top 3", origem: "https://top3agenciamentos.com.br", casa: "https://top3agenciamentos.com.br/empreendimentos/"},
};
const VALIDADE_H = 6;   // depois de 6 h a lista é baixada de novo (em segundo plano)
const DWV_IMG = "https://dwvimagesv1.b-cdn.net/";

// ---------- rodar uma função "dentro" do site (com o login do corretor)
// 1º tenta direto daqui (a extensão tem permissão no site); se o site disser que não está logado, roda numa aba
// do próprio site (abre uma em segundo plano se não houver e fecha depois).
async function noSite(fonte, func, args){
  const F = FONTES[fonte];
  try {
    const r = await func(F.origem, ...(args || []));
    if (r && !r.erro) return r;
    if (r && r.erro && r.erro !== "login") return r;
  } catch (_) { /* sem cookie ou bloqueado: tenta pela aba */ }
  let [aba] = await chrome.tabs.query({url: F.origem + "/*"});
  let criada = false;
  if (!aba) {
    aba = await chrome.tabs.create({url: F.casa, active: false});
    criada = true;
    await new Promise((ok) => {
      const fim = setTimeout(done, 25000);
      function done(){ clearTimeout(fim); chrome.tabs.onUpdated.removeListener(ouvir); ok(); }
      function ouvir(id, info){ if (id === aba.id && info.status === "complete") done(); }
      chrome.tabs.onUpdated.addListener(ouvir);
    });
  }
  try {
    const [res] = await chrome.scripting.executeScript({target: {tabId: aba.id}, func, args: ["", ...(args || [])]});
    return res && res.result || {erro: "Não consegui ler o " + F.nome + "."};
  } catch (e) {
    return {erro: "Não consegui abrir o " + F.nome + " (" + (e.message || e) + ")."};
  } finally {
    if (criada) chrome.tabs.remove(aba.id).catch(() => {});
  }
}

// ---------- funções que rodam no site (sem variáveis de fora: o Chrome copia só o corpo delas)
async function dwvBaixar(base){
  const caixas = [   // litoral de Piçarras a Gov. Celso Ramos, em 3 pedaços (cada pedido demora ~7 s)
    [[-26.70, -48.40], [-26.98, -48.85]],
    [[-26.98, -48.40], [-27.13, -48.85]],
    [[-27.13, -48.40], [-27.40, -48.85]],
  ];
  const pedir = async ([ne, sw]) => {
    const r = await fetch(base + "/api/internal/map", {method: "POST", credentials: "include",
      headers: {"content-type": "application/json"},
      body: JSON.stringify({propertyType: "UNIT", locationBoundary: {northEast: {latitude: ne[0], longitude: ne[1]}, southWest: {latitude: sw[0], longitude: sw[1]}}})});
    if (r.status === 401 || r.status === 403) throw new Error("login");
    if (!r.ok) throw new Error("HTTP " + r.status);
    return (await r.json()).data || [];
  };
  // UM pedido por vez: com pedidos juntos o DWV devolve a lista vazia (testado em 17/11/2026)
  const partes = [];
  try {
    for (const c of caixas) {
      let d = await pedir(c);
      if (!d.length) { await new Promise((ok) => setTimeout(ok, 1500)); d = await pedir(c); }
      partes.push(d);
    }
  } catch (e) { return {erro: e.message === "login" ? "login" : "O DWV não respondeu (" + e.message + ")."}; }
  if (!partes.flat().length) return {erro: "O DWV devolveu a lista vazia. Clique em ↻ daqui a pouco."};
  const vistos = new Map();
  partes.flat().forEach((x) => {
    if (vistos.has(x.reDevelopmentId)) return;
    const n = (v) => (v === null || v === undefined || v === "" ? null : Number(v));
    vistos.set(x.reDevelopmentId, {
      f: "dwv", id: x.reDevelopmentId, nome: String(x.reDevelopmentName || x.name || "").trim(),
      constr: String(x.reDeveloperName || "").trim(), cidade: x.cityName || "", bairro: "",
      rua: String(x.addressStreetName || "").trim(),
      q: [n(x.minBedrooms ?? x.bedrooms), n(x.maxBedrooms ?? x.bedrooms)], s: n(x.suites),
      vg: [n(x.minGarages ?? x.garages), n(x.maxGarages ?? x.garages)],
      a: [n(x.minPrivateArea ?? x.privateArea), n(x.maxPrivateArea ?? x.privateArea)],
      p: n(x.price), ent: x.deliveryDate || "", prog: n(x.reDevelopmentProgress),
      foto: x.reDevelopmentCoverPath || x.coverPath || "", up: x.updatedAt || "",
      // tipo pela categoria do DWV; fase pelo andamento da obra (0% = lançamento, 100% = pronto)
      tipo: ({commercial_room: "Sala comercial", custom_house: "Casa", house: "Casa", studio: "Studio/Flat", flat: "Studio/Flat",
        duplex: "Cobertura/Duplex", penthouse: "Cobertura/Duplex", lot: "Terreno", land: "Terreno"})[x.category] || "Apartamento",
      fase: n(x.reDevelopmentProgress) >= 100 ? "pronto" : n(x.reDevelopmentProgress) > 0 ? "obras" : "planta",
      promo: x.status === "promotional", ban: n(x.bathrooms ?? x.minBathrooms),
    });
  });
  return {itens: [...vistos.values()]};
}

async function dwvCriarLink(base, devId, titulo){
  const q = "mutation createTrackedLink($title: String, $reDevelopmentId: UUID4) { createTrackedLink(input: {title: $title, reDevelopmentId: $reDevelopmentId}) { id title } }";
  const r = await fetch(base + "/api/graphql", {method: "POST", credentials: "include", headers: {"content-type": "application/json"},
    body: JSON.stringify({operationName: "createTrackedLink", variables: {reDevelopmentId: devId, title: titulo}, query: q})});
  if (r.status === 401 || r.status === 403) return {erro: "login"};
  const j = await r.json();
  const id = j && j.data && j.data.createTrackedLink && j.data.createTrackedLink.id;
  if (!id) return {erro: (j && j.errors && j.errors[0] && j.errors[0].message) || "O DWV não criou o link."};
  // o 2º pedaço do link é o id do corretor no DWV (cookie do site). Fora do site, quem lê é a extensão.
  let uid = "";
  if (!base) { const m = document.cookie.match(/(?:^|;\s*)@dwvapp:userId=([^;]+)/); uid = m ? decodeURIComponent(m[1]) : ""; }
  return {linkId: id, uid};
}

async function top3Ficha(base, url){
  const r = await fetch(url.replace("https://top3agenciamentos.com.br", base || ""), {credentials: "include"});
  if (/\/login\//.test(r.url)) return {erro: "login"};
  const d = new DOMParser().parseFromString(await r.text(), "text/html");
  const folhas = [...d.querySelectorAll("body *")].filter((e) => !e.children.length);
  const depois = (rot) => {
    const i = folhas.findIndex((e) => e.textContent.trim() === rot);
    if (i < 0) return "";
    for (let k = i + 1; k < Math.min(i + 6, folhas.length); k++) { const t = folhas[k].textContent.trim(); if (t) return t; }
    return "";
  };
  const desc = d.getElementById("descricao-texto");
  const texto = desc ? [...desc.querySelectorAll("p")].map((p) => p.innerHTML.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/⁠/g, "").split("\n").map((l) => l.trim()).filter(Boolean).join("\n")).join("\n\n") : "";
  // forma de pagamento: o bloco de texto logo depois do título (linhas separadas por <br>)
  const h = [...d.querySelectorAll("h1,h2,h3,h4,h5,h6")].find((e) => /^\s*FORMA DE PAGAMENTO\s*$/i.test(e.textContent));
  let pagamento = [];
  if (h) {
    const wdg = h.closest(".elementor-widget") || h.parentElement, nx = wdg && wdg.nextElementSibling;
    if (nx) pagamento = [...nx.querySelectorAll("p,li")].flatMap((p) => p.innerHTML.split(/<br\s*\/?>/i))
      .map((x) => x.replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim()).filter(Boolean);
  }
  const info = (rot) => { const m = texto.match(new RegExp(rot + "\\s*:?\\s*([^\\n]+)", "i")); return m ? m[1].trim() : ""; };
  return {
    endereco: (desc && desc.querySelector("p") ? desc.querySelector("p").innerHTML.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").split("\n").slice(1).map((s) => s.trim()).filter(Boolean).join(", ") : ""),
    iptu: depois("IPTU"), condominio: depois("Condomínio"), valor: depois("Valor Total"),
    suites: depois("Suítes"), fase: depois("Fase:"), entrega: info("Data de entrega"), construtora: info("Construtora"),
    descricao: texto, pagamento, agenciador: depois("Agenciador"),
  };
}

// fotos do Top 3: a galeria vem pela API pública (a página monta a galeria por script)
async function top3Fotos(wp){
  const r = await fetch(`${FONTES.top3.origem}/wp-json/wp/v2/imovel/${wp}?_fields=acf`);
  if (!r.ok) return [];
  const j = JSON.parse((await r.text()).replace(/^\uFEFF/, ""));
  const g = (((j.acf || {}).photo_gallery || {}).galeria_de_imagens || []).flat().filter((x) => x && x.full_image_url);
  return g.slice(0, 40).map((x) => {
    const ss = String(x.large_srcset || "").split(",").map((s) => s.trim().split(" "));
    const m = ss.find((q) => /^(10\d\d|1[1-6]\d\d)w$/.test(q[1] || "")) || ss.find((q) => /^[7-9]\d\dw$/.test(q[1] || ""));
    return {g: m ? m[0] : x.full_image_url, t: x.thumbnail_image_url || x.full_image_url};
  });
}

// ---------- Top 3: lista pública, guardada por id e baixada só no que mudou
async function top3Baixar(cacheAnt){
  const base = FONTES.top3.origem;
  const ant = new Map((cacheAnt || []).map((x) => [x.id, x]));
  const ids = [];
  for (let pg = 1; pg < 40; pg++) {
    const r = await fetch(`${base}/wp-json/wp/v2/imovel?per_page=100&page=${pg}&_fields=id,modified`);
    if (r.status === 400) break;
    if (!r.ok) return {erro: "O Top 3 não respondeu (HTTP " + r.status + ")."};
    const j = JSON.parse((await r.text()).replace(/^﻿/, ""));
    ids.push(...j);
    const tot = Number(r.headers.get("X-WP-TotalPages") || 1);
    if (pg >= tot) break;
  }
  const faltam = ids.filter((x) => !ant.has("t3-" + x.id) || ant.get("t3-" + x.id).up !== x.modified);
  const novos = new Map();
  let i = 0;
  async function trabalhador(){
    while (i < faltam.length) {
      const x = faltam[i++];
      try {
        const r = await fetch(`${base}/wp-json/extds/v1/imovel/${x.id}`);
        if (!r.ok) continue;
        const c = JSON.parse((await r.text()).replace(/^﻿/, ""));
        const num = (s) => { const m = String(s || "").replace(/\./g, "").replace(",", ".").match(/[\d.]+/); return m ? Number(m[0]) : null; };
        novos.set("t3-" + x.id, {
          f: "top3", id: "t3-" + x.id, wp: x.id, nome: String(c.titulo || "").trim(), constr: "", cidade: c.cidade || "", bairro: c.bairro || "",
          rua: "", un: c.unidade || "", tipo: tipoTop3(c.tipo), ban: c.banheiros ?? null, q: [c.dormitorios ?? null, c.dormitorios ?? null], s: null,
          vg: [c.vagas ?? null, c.vagas ?? null], a: [num(c.area), num(c.area)], p: num(c.preco), ent: "", prog: null,
          foto: c.thumb || "", link: c.link || "", up: x.modified,
        });
      } catch (_) { /* um que falhou não derruba a lista */ }
    }
  }
  await Promise.all(Array.from({length: 8}, trabalhador));
  const lista = ids.map((x) => novos.get("t3-" + x.id) || ant.get("t3-" + x.id)).filter(Boolean);
  return {itens: lista};
}

function tipoTop3(t){
  const n = String(t || "").toLowerCase();
  if (/sala|ponto/.test(n)) return "Sala comercial";
  if (/terreno|lote/.test(n)) return "Terreno";
  if (/studio|flat/.test(n)) return "Studio/Flat";
  if (/cobertura|duplex/.test(n)) return "Cobertura/Duplex";
  if (/casa|sobrado/.test(n)) return "Casa";
  return "Apartamento";
}

// Top 3: fase, suítes, vista pro mar e o que o dono aceita vêm dos filtros do mapa deles (API pública, 1 pedido por filtro).
// Pesado (~13 MB no total), então só 1 vez por dia.
const MARCAS_TOP3 = [
  ["fase", "planta", "status[]=Planta"], ["fase", "pronto", "status[]=Mobiliado", "mobiliado"], ["fase", "pronto", "status[]=Semimobiliado", "semimobiliado"],
  ["fase", "pronto", "status[]=Sem%20mobilia", "sem mobília"], ["tipo", "Terreno", "status[]=Terreno"],
  ["s", 1, "suite[]=1"], ["s", 2, "suite[]=2"], ["s", 3, "suite[]=3"], ["s", 4, "suite[]=4"], ["s", 5, "suite[]=5"],
  ["mar", true, "tem_vista_para_o_mar[]=Sim"], ["fin", true, "aceita_financiamento[]=Sim"],
  ["permuta", true, "aceita_permuta_na_troca[]=Sim"], ["veiculo", true, "aceita_veiculo[]=Sim"],
];
async function top3Marcas(){
  const m = {};
  for (const [campo, valor, q, mob] of MARCAS_TOP3) {
    try {
      const r = await fetch(`${FONTES.top3.origem}/wp-json/extds/v1/markers?${q}`);
      if (!r.ok) continue;
      const lista = JSON.parse((await r.text()).replace(/^\uFEFF/, ""));
      lista.forEach((x) => { const o = m["t3-" + x.id] || (m["t3-" + x.id] = {}); o[campo] = valor; if (mob) o.mob = mob; });
    } catch (_) { /* um filtro que falhou não derruba os outros */ }
  }
  return m;
}
function aplicarMarcas(lista, marcas){
  if (!marcas) return lista;
  return lista.map((it) => Object.assign({}, it, marcas[it.id] || {}));
}

// ---------- cache (v2: tipo, fase, suítes e marcas do Top 3 entraram; a versão nova baixa tudo de novo)
const IMOVEIS = {dwv: [], top3: [], top3cru: [], marcas: null, quando: {}, erro: {}, baixando: {}};
async function carregarImoveis(forcar, aoMudar){
  const g = await chrome.storage.local.get(["imv2:dwv", "imv2:top3", "imv2:quando", "imv2:marcas"]);
  IMOVEIS.dwv = g["imv2:dwv"] || []; IMOVEIS.marcas = g["imv2:marcas"] || null;
  IMOVEIS.top3cru = g["imv2:top3"] || []; IMOVEIS.top3 = aplicarMarcas(IMOVEIS.top3cru, IMOVEIS.marcas); IMOVEIS.quando = g["imv2:quando"] || {};
  aoMudar && aoMudar();
  const velho = (f) => forcar || !IMOVEIS.quando[f] || Date.now() - IMOVEIS.quando[f] > VALIDADE_H * 36e5;
  const tarefas = [];
  if (velho("top3")) tarefas.push(atualizarFonte("top3", () => top3Baixar(IMOVEIS.top3cru), aoMudar).then(async () => {
    const dia = !IMOVEIS.quando.marcas || Date.now() - IMOVEIS.quando.marcas > 24 * 36e5;
    if (!(forcar || dia || !IMOVEIS.marcas)) return;
    const m = await top3Marcas();
    if (Object.keys(m).length) {
      IMOVEIS.marcas = m; IMOVEIS.quando.marcas = Date.now(); IMOVEIS.top3 = aplicarMarcas(IMOVEIS.top3cru, m);
      await chrome.storage.local.set({"imv2:marcas": m, "imv2:quando": IMOVEIS.quando}); aoMudar && aoMudar();
    }
  }));
  if (velho("dwv")) tarefas.push(atualizarFonte("dwv", () => noSite("dwv", dwvBaixar), aoMudar));
  await Promise.all(tarefas);
}
async function atualizarFonte(f, fn, aoMudar){
  if (IMOVEIS.baixando[f]) return;
  IMOVEIS.baixando[f] = true; IMOVEIS.erro[f] = ""; aoMudar && aoMudar();
  try {
    const r = await fn();
    if (r.erro) IMOVEIS.erro[f] = r.erro === "login" ? `Entre no ${FONTES[f].nome} neste Chrome (${FONTES[f].casa.replace(/^https:\/\//, "").split("/")[0]}) e clique em ↻.` : r.erro;
    else if (r.itens && r.itens.length) {
      if (f === "top3") { IMOVEIS.top3cru = r.itens; IMOVEIS.top3 = aplicarMarcas(r.itens, IMOVEIS.marcas); } else IMOVEIS[f] = r.itens;
      IMOVEIS.quando[f] = Date.now();
      await chrome.storage.local.set({["imv2:" + f]: r.itens, "imv2:quando": IMOVEIS.quando});
    }
  } catch (e) { IMOVEIS.erro[f] = String(e.message || e); }
  IMOVEIS.baixando[f] = false; aoMudar && aoMudar();
}
const todosImoveis = () => [...IMOVEIS.dwv, ...IMOVEIS.top3];

// ---------- link do DWV pro cliente
async function linkDWV(it, cliente){
  const titulo = (cliente || "Cliente") + " · " + new Date().toLocaleDateString("pt-BR");
  const r = await noSite("dwv", dwvCriarLink, [it.id, titulo]);
  if (r.erro) return r;
  let uid = r.uid;
  if (!uid) { const c = await chrome.cookies.get({url: FONTES.dwv.origem, name: "@dwvapp:userId"}).catch(() => null); uid = c ? decodeURIComponent(c.value) : ""; }
  if (!uid) return {erro: "Não achei o seu usuário do DWV. Entre no DWV neste Chrome e tente de novo."};
  return {url: `https://hotsite.dwvapp.com.br/tracked_re_development/${r.linkId.replace(/-/g, "")}/${uid.replace(/-/g, "")}`};
}

// ---------- fotos do Top 3 prontas pro WhatsApp (JPEG de até 1600 px, como data URL)
async function fotoParaZap(url){
  const r = await fetch(url); if (!r.ok) throw new Error("HTTP " + r.status);
  const bmp = await createImageBitmap(await r.blob());
  const esc = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
  const c = new OffscreenCanvas(Math.round(bmp.width * esc), Math.round(bmp.height * esc));
  c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
  const b = await c.convertToBlob({type: "image/jpeg", quality: 0.82});
  return await new Promise((ok) => { const fr = new FileReader(); fr.onload = () => ok(fr.result); fr.readAsDataURL(b); });
}

// ---------- o que o cliente procura, pelo que ELE escreveu na conversa
const CIDADES = [
  ["Itapema", /itapema|meia praia/], ["Porto Belo", /porto belo|perequ/], ["Bombinhas", /bombinhas|mariscal|zimbros/],
  ["Balneário Camboriú", /balneario camboriu|\bbc\b|camboriu/], ["Itajaí", /itajai|praia brava|cabecudas/], ["Navegantes", /navegantes/],
  ["Tijucas", /tijucas/], ["Gov. Celso Ramos", /celso ramos/],
];
const NUMS = {um: 1, uma: 1, dois: 2, duas: 2, tres: 3, quatro: 4, cinco: 5};
function oQueProcura(conversa){
  const txt = norm((conversa || []).filter((m) => m.de !== "eu").map((m) => m.t).join(" \n "));
  if (!txt) return null;
  const p = {};
  const cid = CIDADES.filter(([, re]) => re.test(txt)).map(([c]) => c);
  if (cid.length) p.cidades = cid;
  const mq = txt.match(/\b(\d|um|uma|dois|duas|tres|quatro|cinco)\s*(quartos?|dormitorios?|dorms?|suites?)\b/);
  if (mq) p.quartos = Number(NUMS[mq[1]] || mq[1]);
  const mo = txt.match(/(?:ate|teto|maximo|no maximo|uns|em torno de|por volta de|orcamento|budget|r\$)\s*(?:de\s*)?(?:r\$\s*)?(\d+(?:[.,]\d+)?)\s*(mil\b|k\b|milh(?:ao|oes)|mi\b|m\b)/);
  if (mo) { const v = Number(mo[1].replace(",", ".")); p.ate = /^(mil|k)$/.test(mo[2]) ? v * 1e3 : v * 1e6; }
  if (/frente (pro |para o )?mar|frente-mar|pe na areia|beira[ -]mar/.test(txt)) p.mar = "frente mar";
  else if (/vista (pro|para o|do) mar/.test(txt)) p.mar = "vista mar";
  if (/pronto pra morar|pronto para morar|(imovel|apartamento|ape|apto|casa) pronto|ja pronto/.test(txt)) p.fase = "pronto";
  else if (/na planta|lancamento/.test(txt)) p.fase = "planta";
  return Object.keys(p).length ? p : null;
}
// a frase do jeito que se fala: "3 quartos em Itapema até R$ 1,5 milhão"
function procuraFalada(p){
  if (!p) return "";
  const din = (v) => v >= 1e6 ? "R$ " + (v / 1e6).toLocaleString("pt-BR", {maximumFractionDigits: 2}) + (v < 2e6 ? " milhão" : " milhões") : "R$ " + Math.round(v / 1e3) + " mil";
  return [p.quartos && `${p.quartos} quarto${p.quartos > 1 ? "s" : ""}`, p.mar, p.cidades && "em " + p.cidades.join(" ou "),
    p.fase === "pronto" ? "pronto pra morar" : p.fase === "planta" ? "na planta" : "", p.ate && "até " + din(p.ate)].filter(Boolean).join(" ");
}
// o imóvel bate com o que o cliente pediu? (só aí a mensagem cita o pedido dele)
function bateCom(it, p){
  if (!p) return false;
  const q = it.q[1] ?? it.q[0];
  if (p.quartos && !(q >= p.quartos)) return false;
  if (p.ate && !(it.p && it.p <= p.ate * 1.05)) return false;
  if (p.cidades && !p.cidades.some((c) => norm(it.cidade).includes(norm(c).replace(/^bal\.? /, "").slice(0, 6)) || norm(c).includes(norm(it.cidade).slice(0, 6)))) return false;
  return true;
}
function descreverProcura(p){
  if (!p) return "";
  return [p.cidades && p.cidades.join(" ou "), p.quartos && `${p.quartos} quarto${p.quartos > 1 ? "s" : ""}`,
    p.ate && "até " + dinheiroCurto(p.ate), p.mar, p.fase === "pronto" ? "pronto pra morar" : p.fase === "planta" ? "na planta" : ""].filter(Boolean).join(" · ");
}

// ---------- formatação
const real = (v) => v ? "R$ " + Math.round(v).toLocaleString("pt-BR") : "";
function dinheiroCurto(v){
  if (!v) return "";
  if (v >= 1e6) return "R$ " + (v / 1e6).toLocaleString("pt-BR", {maximumFractionDigits: 2}) + " mi";
  return "R$ " + Math.round(v / 1e3) + " mil";
}
const faixa = (par, suf) => {
  const [a, b] = par || [];
  if (a == null && b == null) return "";
  const f = (x) => Number.isInteger(x) ? String(x) : x.toLocaleString("pt-BR", {maximumFractionDigits: 1});
  return (a != null && b != null && a !== b ? `${f(a)} a ${f(b)}` : f(a ?? b)) + (suf || "");
};
function fotoDe(it, larg){
  if (!it.foto) return "";
  if (it.f !== "dwv") return it.foto;
  const u = /^https?:/.test(it.foto) ? it.foto : DWV_IMG + it.foto;
  return /b-cdn\.net/.test(u) ? u.split("?")[0] + "?width=" + (larg || 200) : u;
}
function ondeFica(it){ return [it.bairro, it.cidade].filter(Boolean).join(", "); }
function quartosTxt(it){ const q = faixa(it.q); return q ? q + (q === "1" ? " quarto" : " quartos") : ""; }
function entregaTxt(it){
  if (!it.ent) return "";
  const d = new Date(it.ent); if (isNaN(d)) return it.ent;
  const mes = ["jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez"][d.getUTCMonth()];
  return d < new Date() ? "pronto" : `entrega ${mes}/${d.getUTCFullYear()}`;
}
