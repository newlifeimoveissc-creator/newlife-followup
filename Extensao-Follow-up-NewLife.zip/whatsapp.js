// Roda dentro do WhatsApp Web. Recebe do painel: "contato" (nome da conversa aberta) e "colocar" (vídeo + legenda na conversa aberta).
// Nunca aperta Enviar: o corretor confere e envia.

const espera = (ms) => new Promise((r) => setTimeout(r, ms));
const visivel = (el) => !!el && el.getClientRects().length > 0;

function nomeDaConversa() {
  const h = document.querySelector("#main header");
  if (!h) return "";
  const el = h.querySelector("span[dir='auto'][title]") || h.querySelector("span[dir='auto']");
  return (el && (el.getAttribute("title") || el.textContent) || "").trim();
}

function caixaDeTexto() {
  return document.querySelector("#main footer div[contenteditable='true']");
}

// a caixa de legenda aparece na tela de prévia do anexo (fora do rodapé da conversa)
function caixaDeLegenda() {
  const todas = [...document.querySelectorAll("div[contenteditable='true']")].filter(visivel);
  const fora = todas.filter((el) => !el.closest("#main footer") && !el.closest("#side"));
  return fora[fora.length - 1] || null;
}

async function esperar(fn, ms) {
  const fim = Date.now() + ms;
  while (Date.now() < fim) { const r = fn(); if (r) return r; await espera(150); }
  return null;
}

// Escreve a mensagem na caixa do WhatsApp sem apertar Enviar.
// 1º cola o texto inteiro de uma vez (como o ⌘V: o WhatsApp mantém as quebras de linha);
// se não entrar, digita linha a linha. Antes de cada quebra vai um espaço: se o WhatsApp engolir a quebra,
// o link não gruda na palavra de baixo (".../fipezap/Já" abria página 404).
const plano = (s) => (s || "").replace(/ /g, " ").replace(/\s+/g, " ").trim();
const LINK = /https?:\/\/[^\s]+/g;
function confere(el, texto) {
  const t = " " + plano(el.innerText) + " ";
  const comeco = plano(texto).slice(0, 24);
  const links = (texto.match(LINK) || []);
  const linkOk = links.every((u) => new RegExp(u.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(\\s|$)").test(t));
  return { escreveu: t.includes(comeco), linkOk };
}
async function escrever(el, texto) {
  const seguro = texto.replace(/[ \t]*\n/g, " \n");
  el.focus();
  const sel = window.getSelection(); sel.selectAllChildren(el); sel.collapseToEnd();
  const dt = new DataTransfer(); dt.setData("text/plain", seguro);
  el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
  let r = null;
  for (let i = 0; i < 8; i++) { await espera(100); r = confere(el, texto); if (r.escreveu) break; }
  if (!r.escreveu) {
    el.focus(); sel.selectAllChildren(el); sel.collapseToEnd();
    seguro.split("\n").forEach((l, i) => { if (i) document.execCommand("insertLineBreak"); if (l) document.execCommand("insertText", false, l); });
    await espera(150); r = confere(el, texto);
  }
  return r;
}

async function anexarPorColar(arquivo) {
  const caixa = caixaDeTexto(); if (!caixa) return false;
  caixa.focus();
  const dt = new DataTransfer(); [].concat(arquivo).forEach((a) => dt.items.add(a));
  caixa.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
  return !!(await esperar(caixaDeLegenda, 6000));
}

async function anexarPeloClipe(arquivo) {
  const botao = document.querySelector("#main footer [data-icon='plus-rounded'], #main footer [data-icon='plus'], #main footer [data-icon='attach-menu-plus'], #main footer [data-icon='clip'], #main footer button[title*='Anexar'], #main footer div[title*='Anexar'], #main footer [aria-label*='Anexar'], #main footer [aria-label*='Attach']");
  if (botao) { (botao.closest("button,[role='button'],div[title]") || botao).click(); await espera(500); }
  const entrada = [...document.querySelectorAll("input[type='file']")].find((i) => /video|image|\*/.test(i.accept || "")) || document.querySelector("input[type='file']");
  if (!entrada) return false;
  const dt = new DataTransfer(); [].concat(arquivo).forEach((a) => dt.items.add(a));
  entrada.files = dt.files;
  entrada.dispatchEvent(new Event("change", { bubbles: true }));
  return !!(await esperar(caixaDeLegenda, 8000));
}

async function colocar({ url, nomeArquivo, texto }) {
  if (!document.querySelector("#main")) return { ok: false, erro: "Abra a conversa do cliente no WhatsApp primeiro." };
  let blob;
  try {
    const r = await fetch(url); if (!r.ok) throw new Error("HTTP " + r.status);
    blob = await r.blob();
  } catch (e) { return { ok: false, erro: "Não consegui baixar o vídeo (" + e.message + "). Confira a internet." }; }
  const arquivo = new File([blob], nomeArquivo, { type: "video/mp4" });
  let anexou = await anexarPorColar(arquivo);
  if (!anexou) anexou = await anexarPeloClipe(arquivo);
  if (!anexou) return { ok: false, erro: "O WhatsApp não abriu a prévia do vídeo. A mensagem está copiada: anexe o vídeo pelo clipe e cole." };
  await espera(300);
  const leg = caixaDeLegenda();
  const r = leg ? await escrever(leg, texto) : { escreveu: false, linkOk: true };
  return { ok: true, legenda: r.escreveu, linkOk: r.linkOk };
}

// fotos (do Top 3) + texto de legenda. As fotos chegam prontas do painel (JPEG em data URL), porque daqui o site do Top 3 não deixa baixar.
async function colocarArquivos({ arquivos, texto }) {
  if (!document.querySelector("#main")) return { ok: false, erro: "Abra a conversa do cliente no WhatsApp primeiro." };
  const files = [];
  for (const a of arquivos || []) {
    try { const b = await (await fetch(a.dataUrl)).blob(); files.push(new File([b], a.nome, { type: a.tipo || b.type })); } catch (_) {}
  }
  if (!files.length) return { ok: false, erro: "Não consegui preparar as fotos." };
  let anexou = await anexarPorColar(files);
  if (!anexou) anexou = await anexarPeloClipe(files);
  if (!anexou) return { ok: false, erro: "O WhatsApp não abriu a prévia das fotos. O texto está copiado: anexe as fotos pelo clipe e cole." };
  await espera(400);
  const leg = caixaDeLegenda();
  const r = leg ? await escrever(leg, texto) : { escreveu: false, linkOk: true };
  return { ok: true, legenda: r.escreveu, linkOk: r.linkOk };
}

// últimas mensagens da conversa aberta, para sugerir o vídeo certo. Fica só no computador do corretor: o painel lê e não manda pra lugar nenhum.
function conversa(max) {
  const els = [...document.querySelectorAll("#main [data-pre-plain-text]")].slice(-(max || 40));
  const chat = nomeDaConversa().replace(/\s+/g, " ").trim();
  return els.map((el) => {
    const pre = el.getAttribute("data-pre-plain-text") || "";
    const m = pre.match(/\[(\d{1,2}):(\d{2})[^,\]]*,\s*(\d{1,2})\/(\d{1,2})\/(\d{4})\]/);
    const quando = m ? new Date(+m[5], +m[4] - 1, +m[3], +m[1], +m[2]).getTime() : 0;
    const linha = el.closest(".message-in, .message-out");
    // quem escreveu: pela classe da bolha; se o WhatsApp mudar a classe, pelo autor que vem no próprio texto ("[hora, data] Nome: ")
    const autor = pre.replace(/^\[[^\]]*\]\s*/, "").replace(/:\s*$/, "").replace(/\s+/g, " ").trim();
    const de = linha ? (linha.classList.contains("message-out") ? "eu" : "cliente") : autor && chat ? (autor === chat ? "cliente" : "eu") : "?";
    const alvo = el.querySelector(".selectable-text") || el;
    return { de, t: (alvo.innerText || "").trim().slice(0, 500), quando };
  }).filter((x) => x.t);
}

async function colocarTexto({ texto }) {
  const caixa = caixaDeTexto();
  if (!caixa) return { ok: false, erro: "Abra a conversa do cliente no WhatsApp primeiro." };
  const r = await escrever(caixa, texto);
  return { ok: true, escreveu: r.escreveu, linkOk: r.linkOk };
}

chrome.runtime.onMessage.addListener((msg, _de, responder) => {
  if (msg && msg.acao === "contato") { const aberta = !!document.querySelector("#main"); responder({ nome: nomeDaConversa(), aberta, conversa: aberta ? conversa(40) : [] }); return; }
  if (msg && msg.acao === "texto") { colocarTexto(msg).then(responder, (e) => responder({ ok: false, erro: String(e && e.message || e) })); return true; }
  if (msg && msg.acao === "colocarArquivos") { colocarArquivos(msg).then(responder, (e) => responder({ ok: false, erro: String(e && e.message || e) })); return true; }
  if (msg && msg.acao === "colocar") { colocar(msg).then(responder, (e) => responder({ ok: false, erro: String(e && e.message || e) })); return true; }
});
